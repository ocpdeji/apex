import { execFile } from "node:child_process";
import { readFileSync, rmSync, writeFileSync } from "node:fs";
import { request as httpRequest } from "node:http";
import { request as httpsRequest } from "node:https";
import { basename } from "node:path";
import { promisify } from "node:util";

// VoiceStudio (github.com/debpalash/VoiceStudio) is a separate free desktop app. While it is open its backend listens on
// localhost and speaks a plain HTTP API, so nothing is installed into flow-mcp: we only talk to it. Loopback callers need
// no key; a backend on another machine takes OMNIVOICE_API_KEY like VoiceStudio's own clients.
const run = promisify(execFile);
const FFMPEG = process.env.FLOW_MCP_FFMPEG ?? "ffmpeg";
export const VS_URL = (process.env.VOICESTUDIO_URL ?? `http://127.0.0.1:${process.env.OMNIVOICE_PORT ?? 3900}`).replace(/\/+$/, "");
const KEY = process.env.OMNIVOICE_API_KEY?.trim();
const auth = (): Record<string, string> => (KEY ? { authorization: `Bearer ${KEY}` } : {});

// Steps the diffusion model takes per take: more is cleaner and slower. VoiceStudio's own labels.
export const VS_QUALITY = { draft: 8, balanced: 16, studio: 32 } as const;

export const VS_INSTALL = {
  windows: "Open PowerShell and run:  irm https://voicestudio.sh/install | iex   (or download the .exe from github.com/debpalash/VoiceStudio/releases/latest)",
  mac: "Open Terminal and run:  curl -fsSL https://voicestudio.sh/install | sh   (or download the .dmg from github.com/debpalash/VoiceStudio/releases/latest)",
  then: "Open VoiceStudio once and let it finish its first-run setup (it downloads its voice model, about 2.3 GB). Keep it open while Flow uses it.",
};

const notRunning = () =>
  new Error(
    `VoiceStudio isn't running (nothing answered at ${VS_URL}).\n\n` +
      `1. If it isn't installed yet: ${process.platform === "win32" ? VS_INSTALL.windows : VS_INSTALL.mac}\n` +
      `2. ${VS_INSTALL.then}\n` +
      `3. Try again.`,
  );

async function getJson<T>(path: string, timeoutMs = 8000): Promise<T> {
  const res = await fetch(VS_URL + path, { headers: auth(), signal: AbortSignal.timeout(timeoutMs) }).catch(() => null);
  if (!res) throw notRunning();
  const body = await res.json().catch(() => null);
  if (!res.ok) throw new Error(`VoiceStudio refused ${path} (${res.status}): ${detail(body)}`);
  return body as T;
}

const detail = (body: unknown): string => {
  const d = (body as { detail?: unknown } | null)?.detail;
  if (typeof d === "string") return d;
  if (Array.isArray(d)) return d.map((x) => (x as { msg?: string }).msg ?? JSON.stringify(x)).join("; ");
  return d ? JSON.stringify(d) : "no detail";
};

// A take on a computer without a graphics card can run for many minutes before VoiceStudio sends a single header, and
// fetch gives up on headers after five. node:http has no such limit, so posts go through it with our own deadline.
async function postForm(path: string, form: FormData, timeoutMs: number): Promise<{ status: number; headers: Record<string, string>; body: Buffer }> {
  const encoded = new Request("http://form.local", { method: "POST", body: form });
  const payload = Buffer.from(await encoded.arrayBuffer());
  const url = new URL(VS_URL + path);
  const send = url.protocol === "https:" ? httpsRequest : httpRequest;
  return new Promise((ok, fail) => {
    const req = send(
      url,
      { method: "POST", headers: { ...auth(), "content-type": encoded.headers.get("content-type") ?? "", "content-length": payload.length } },
      (res) => {
        const chunks: Buffer[] = [];
        res.on("data", (c: Buffer) => chunks.push(c));
        res.on("end", () => {
          const headers: Record<string, string> = {};
          for (const [k, v] of Object.entries(res.headers)) if (typeof v === "string") headers[k] = v;
          ok({ status: res.statusCode ?? 0, headers, body: Buffer.concat(chunks) });
        });
        res.on("error", fail);
      },
    );
    req.setTimeout(timeoutMs, () => req.destroy(new Error(`VoiceStudio took longer than ${Math.round(timeoutMs / 60000)} minutes.`)));
    req.on("error", (err: NodeJS.ErrnoException) => fail(err.code === "ECONNREFUSED" || err.code === "ENOTFOUND" ? notRunning() : err));
    req.end(payload);
  });
}

const formError = (path: string, r: { status: number; body: Buffer }) => {
  let body: unknown = null;
  try {
    body = JSON.parse(r.body.toString("utf8"));
  } catch {}
  return new Error(`VoiceStudio refused ${path} (${r.status}): ${body ? detail(body) : r.body.toString("utf8").slice(0, 300) || "no detail"}`);
};

interface Profile {
  id: string;
  name: string;
  kind?: string;
  language?: string;
  personality?: string;
  instruct?: string;
}
interface Engine {
  id: string;
  display_name?: string;
  available?: boolean;
  reason?: string | null;
  supports_cloning?: boolean | null;
  supports_voice_design?: boolean | null;
  instruct_vocabulary?: "tags" | "freeform";
  preset_voices?: string[];
  default_voice?: string | null;
  effective_device?: string;
}

export async function voiceStudioStatus() {
  const res = await fetch(VS_URL + "/health", { headers: auth(), signal: AbortSignal.timeout(4000) }).catch(() => null);
  if (!res) return { running: false, ready: false, url: VS_URL, install: VS_INSTALL };
  const body = (await res.json().catch(() => ({}))) as { status?: string; device?: string; version?: string; label?: string };
  if (res.status === 503) return { running: true, ready: false, url: VS_URL, starting: body.label ?? "starting up", version: body.version };
  return { running: true, ready: res.ok && body.status === "ok", url: VS_URL, device: body.device, version: body.version };
}

// Everything the panel and Claude can choose from, read live from the running app. Each part is fetched on its own,
// so one missing endpoint on an older VoiceStudio never hides the rest.
export async function voiceStudioCatalog() {
  const status = await voiceStudioStatus();
  if (!status.ready) return { ...status, voices: [], engines: [], personalities: [], effects: [], qualities: VS_QUALITY };
  const [profiles, engines, personalities, effects] = await Promise.all([
    getJson<Profile[]>("/profiles").catch(() => []),
    getJson<{ active?: string; backends?: Engine[] }>("/engines/tts").catch(() => ({ active: undefined, backends: [] as Engine[] })),
    getJson<{ id: string; name: string; description?: string; instruct?: string }[]>("/personalities").catch(() => []),
    getJson<{ presets?: { id: string; label: string; description?: string }[] }>("/engines/effects/presets").catch(() => ({ presets: [] })),
  ]);
  return {
    ...status,
    voices: profiles.map((p) => ({ id: p.id, name: p.name, kind: p.kind ?? "clone", language: p.language ?? "Auto", personality: p.personality || undefined })),
    active_engine: engines.active,
    engines: (engines.backends ?? []).map((e) => ({
      id: e.id,
      name: e.display_name ?? e.id,
      available: e.available !== false,
      why_not: e.available === false ? e.reason ?? undefined : undefined,
      cloning: e.supports_cloning !== false,
      design: e.supports_voice_design !== false,
      style_words: e.instruct_vocabulary ?? "freeform",
      preset_voices: e.preset_voices ?? [],
      default_voice: e.default_voice ?? undefined,
      device: e.effective_device,
    })),
    personalities: personalities.map((p) => ({ id: p.id, name: p.name, description: p.description, instruct: p.instruct })),
    effects: (effects.presets ?? []).map((e) => ({ id: e.id, label: e.label, description: e.description })),
    qualities: VS_QUALITY,
  };
}

// A voice can be named the way people say it ("Morgan") or by its id; an unknown name is an error, never a silent
// switch to the default voice.
async function resolveProfile(voice: string | undefined): Promise<Profile | undefined> {
  if (!voice?.trim() || /^(default|auto)$/i.test(voice.trim())) return undefined;
  const want = voice.trim().toLowerCase();
  const profiles = await getJson<Profile[]>("/profiles");
  const hit = profiles.find((p) => p.id === voice.trim()) ?? profiles.find((p) => p.name.toLowerCase() === want);
  if (!hit) {
    const names = profiles.map((p) => p.name).join(", ") || "none yet";
    throw new Error(`VoiceStudio has no voice called "${voice}". Saved voices: ${names}. Make one with flow_voice_clone or flow_voice_design, or leave voice empty for VoiceStudio's default.`);
  }
  return hit;
}

export interface VoiceStudioTake {
  voice?: string;
  vs_engine?: string;
  preset_voice?: string;
  language?: string;
  personality?: string;
  style?: string;
  instruct?: string;
  speed?: number;
  quality?: keyof typeof VS_QUALITY;
  steps?: number;
  guidance?: number;
  seed?: number;
  effect?: string;
  denoise?: boolean;
  target_seconds?: number;
  bit_depth?: "16" | "24" | "32";
  pronounce?: boolean;
  normalize?: boolean;
}

// Free-text delivery notes only reach engines that read text. OmniVoice understands a fixed set of words (gender, age,
// pitch, whisper, accent), so its notes go through VoiceStudio's own describe step first and whatever it can't map is
// reported back rather than sent to fail. Engines that only speak in their built-in voices refuse any description, so
// the note is left out for them instead of failing the take.
async function styleToInstruct(style: string, engineId: string | undefined): Promise<{ instruct?: string; ignored: string[] }> {
  const engines = await getJson<{ active?: string; backends?: Engine[] }>("/engines/tts").catch(() => null);
  const id = engineId ?? engines?.active;
  const engine = engines?.backends?.find((e) => e.id === id);
  if (engine?.supports_voice_design === false) return { ignored: [style] };
  if ((engine?.instruct_vocabulary ?? "tags") === "freeform") return { instruct: style, ignored: [] };
  const res = await fetch(VS_URL + "/design/describe", {
    method: "POST",
    headers: { ...auth(), "content-type": "application/json" },
    body: JSON.stringify({ description: style }),
    signal: AbortSignal.timeout(30_000),
  }).catch(() => null);
  if (!res?.ok) return { ignored: [style] };
  const parsed = (await res.json()) as { instruct?: string; unmatched?: string[] };
  return { instruct: parsed.instruct || undefined, ignored: parsed.unmatched ?? [] };
}

export async function speakWithVoiceStudio(text: string, o: VoiceStudioTake, target: string) {
  const status = await voiceStudioStatus();
  if (!status.running) throw notRunning();
  if (!status.ready) throw new Error(`VoiceStudio is still starting (${status.starting}). Wait a moment and try again.`);
  const profile = await resolveProfile(o.voice);
  const personalities = o.personality ? await getJson<{ id: string; name: string; instruct?: string }[]>("/personalities").catch(() => []) : [];
  const persona = o.personality
    ? personalities.find((p) => p.id === o.personality || p.name.toLowerCase() === o.personality!.toLowerCase())
    : undefined;
  if (o.personality && !persona) throw new Error(`VoiceStudio has no personality "${o.personality}". Choose one of: ${personalities.map((p) => p.id).join(", ")}.`);
  const fromStyle = o.style && !o.instruct ? await styleToInstruct(o.style, o.vs_engine) : { instruct: undefined, ignored: [] as string[] };
  // One description per take, never two merged: "elderly" from a note next to a personality's "middle-aged" would
  // argue. The most specific wins - exact instruct, then the delivery note, then the personality.
  const instruct = o.instruct || fromStyle.instruct || persona?.instruct || undefined;

  const form = new FormData();
  const put = (k: string, v: unknown) => v !== undefined && v !== null && v !== "" && form.append(k, String(v));
  put("text", text);
  put("profile_id", profile?.id);
  put("engine", o.vs_engine);
  put("preset_voice", o.preset_voice);
  // Left out, not "Auto": VoiceStudio then uses the voice's own saved language.
  put("language", o.language);
  put("instruct", instruct);
  put("speed", o.speed ?? 1);
  put("num_step", o.steps ?? VS_QUALITY[o.quality ?? "balanced"]);
  put("guidance_scale", o.guidance);
  put("seed", o.seed);
  put("effect_preset", o.effect ?? "broadcast");
  put("denoise", o.denoise === undefined ? undefined : o.denoise ? "true" : "false");
  put("duration", o.target_seconds);
  put("wav_bits", o.bit_depth ?? "24");
  put("pronounce", o.pronounce === undefined ? undefined : o.pronounce ? "true" : "false");

  // Long text is split and crossfaded by VoiceStudio itself; allow a generous minute per 300 characters on a CPU.
  const r = await postForm("/generate", form, Math.max(10 * 60_000, Math.ceil(text.length / 300) * 60_000 + 30 * 60_000));
  if (r.status >= 400) throw formError("/generate", r);

  const wav = target.replace(/\.\w+$/, "") + ".vs.wav";
  writeFileSync(wav, r.body);
  let output = target;
  if (o.normalize === false) {
    // Exactly what VoiceStudio rendered, only rewrapped for the films folder.
    await run(FFMPEG, ["-v", "error", "-y", "-i", wav, "-c:a", "aac", "-b:a", "256k", target]).then(
      () => rmSync(wav, { force: true }),
      () => (output = keepWav(wav, target)),
    );
  } else {
    // Same level as every other narration, so a VoiceStudio line sits evenly next to a Google one in flow_assemble.
    await run(FFMPEG, ["-v", "error", "-y", "-i", wav, "-af", "loudnorm=I=-16:TP=-1.5:LRA=11", "-ar", "48000", "-ac", "2", "-c:a", "aac", "-b:a", "256k", target]).then(
      () => rmSync(wav, { force: true }),
      () => (output = keepWav(wav, target)),
    );
  }
  const duration = Number(r.headers["x-audio-duration"]);
  return {
    output,
    duration: Number.isFinite(duration) ? duration : await probe(output),
    voicestudio: {
      voice: profile ? profile.name : "VoiceStudio default",
      voice_id: profile?.id,
      engine: o.vs_engine ?? "VoiceStudio's selected engine",
      audio_id: r.headers["x-audio-id"],
      render_seconds: Number(r.headers["x-gen-time"]) || undefined,
      instruct,
      style_words_ignored: fromStyle.ignored.length ? fromStyle.ignored : undefined,
      note: output.endsWith(".wav") ? "ffmpeg isn't installed, so the take was kept as a .wav (still usable everywhere)." : undefined,
    },
  };
}

// Without ffmpeg the WAV itself becomes the narration, which every other tool here can read too.
function keepWav(wav: string, target: string): string {
  const out = target.replace(/\.\w+$/, ".wav");
  writeFileSync(out, readFileSync(wav));
  rmSync(wav, { force: true });
  return out;
}

const probe = async (file: string) =>
  Number((await run("ffprobe", ["-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", file]).catch(() => ({ stdout: "0" }))).stdout.trim()) || 0;

export async function cloneVoice(a: { name: string; audio: string; transcript?: string; language?: string; style?: string }) {
  const status = await voiceStudioStatus();
  if (!status.ready) throw status.running ? new Error("VoiceStudio is still starting. Wait a moment and try again.") : notRunning();
  const form = new FormData();
  form.append("name", a.name);
  form.append("kind", "clone");
  form.append("ref_text", a.transcript ?? "");
  form.append("instruct", a.style ?? "");
  form.append("language", a.language ?? "Auto");
  form.append("ref_audio", new Blob([readFileSync(a.audio)]), basename(a.audio));
  const r = await postForm("/profiles", form, 10 * 60_000);
  if (r.status >= 400) throw formError("/profiles", r);
  const p = JSON.parse(r.body.toString("utf8")) as Profile;
  return { voice: p.name, voice_id: p.id, kind: p.kind, use_as: `flow_narrate engine "voicestudio", voice "${p.name}"` };
}

export async function describeVoice(description: string) {
  const res = await fetch(VS_URL + "/design/describe", {
    method: "POST",
    headers: { ...auth(), "content-type": "application/json" },
    body: JSON.stringify({ description }),
    signal: AbortSignal.timeout(30_000),
  }).catch(() => null);
  if (!res) throw notRunning();
  const body = (await res.json().catch(() => null)) as { attrs?: Record<string, string>; instruct?: string; matched?: string[]; unmatched?: string[] } | null;
  if (!res.ok || !body) throw new Error(`VoiceStudio couldn't read that description (${res.status}): ${detail(body)}`);
  return body;
}

export async function designVoice(a: { name: string; description: string; language?: string; preview_only?: boolean }) {
  const parsed = await describeVoice(a.description);
  if (a.preview_only) return { preview: true, understood: parsed.attrs, instruct: parsed.instruct, ignored: parsed.unmatched ?? [] };
  if (!parsed.matched?.length) {
    throw new Error(
      `VoiceStudio couldn't turn that into a voice. It understands: male/female; child, teenager, young adult, middle-aged, elderly; very low to very high pitch; whisper; and accents (american, british, australian, canadian, indian, japanese, korean, chinese, russian, portuguese). For any other voice, clone one from a recording with flow_voice_clone.`,
    );
  }
  const form = new FormData();
  form.append("name", a.name);
  form.append("kind", "design");
  form.append("vd_states", JSON.stringify(parsed.attrs ?? {}));
  form.append("instruct", parsed.instruct ?? "");
  form.append("language", a.language ?? "Auto");
  // Saving renders the voice's fixed sample, which waits its turn like any other take.
  const r = await postForm("/profiles", form, 30 * 60_000);
  if (r.status >= 400) throw formError("/profiles", r);
  const p = JSON.parse(r.body.toString("utf8")) as Profile;
  return { voice: p.name, voice_id: p.id, kind: p.kind, understood: parsed.attrs, ignored: parsed.unmatched ?? [], use_as: `flow_narrate engine "voicestudio", voice "${p.name}"` };
}
