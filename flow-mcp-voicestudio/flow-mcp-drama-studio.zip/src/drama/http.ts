import { readFileSync, writeFileSync } from "node:fs";
import { extname } from "node:path";

// Small shared plumbing for the provider clients: files as data URIs, downloads, polling, and error text people can act on.
const MIME: Record<string, string> = { ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp", ".mp3": "audio/mpeg", ".wav": "audio/wav", ".m4a": "audio/mp4", ".mp4": "video/mp4" };
export const mimeOf = (file: string) => MIME[extname(file).toLowerCase()] ?? "application/octet-stream";
export const dataUri = (file: string) => `data:${mimeOf(file)};base64,${readFileSync(file).toString("base64")}`;
export const b64 = (file: string) => readFileSync(file).toString("base64");

export const extFor = (mime: string | null | undefined, fallback: string) =>
  ({ "image/png": ".png", "image/jpeg": ".jpg", "image/webp": ".webp", "audio/mpeg": ".mp3", "audio/wav": ".wav", "audio/x-wav": ".wav", "video/mp4": ".mp4" } as Record<string, string>)[
    (mime ?? "").split(";")[0].trim()
  ] ?? fallback;

export async function saveDataUri(uri: string, stem: string, fallback = ".png") {
  const m = uri.match(/^data:([^;,]+)(;base64)?,(.*)$/s);
  if (!m) throw new Error("The service returned an image in a form Flow can't read.");
  const file = stem + extFor(m[1], fallback);
  writeFileSync(file, m[2] ? Buffer.from(m[3], "base64") : Buffer.from(decodeURIComponent(m[3])));
  return file;
}

export async function download(url: string, stem: string, fallback: string, headers: Record<string, string> = {}) {
  const res = await fetch(url, { headers, redirect: "follow", signal: AbortSignal.timeout(10 * 60_000) });
  if (!res.ok) throw new Error(`Couldn't download the result (${res.status}).`);
  const file = stem + (extname(new URL(url).pathname) && /\.(mp4|mov|webm|png|jpe?g|webp|mp3|wav)$/i.test(new URL(url).pathname) ? extname(new URL(url).pathname).toLowerCase() : extFor(res.headers.get("content-type"), fallback));
  writeFileSync(file, Buffer.from(await res.arrayBuffer()));
  return file;
}

// Reads a JSON reply, turning any refusal into one sentence naming the service and its own reason.
export async function json<T>(service: string, res: Response): Promise<T> {
  const text = await res.text();
  let body: unknown = undefined;
  try {
    body = text ? JSON.parse(text) : {};
  } catch {}
  if (!res.ok) {
    const b = body as { error?: { message?: string } | string; message?: string; detail?: unknown; msg?: string } | undefined;
    const why =
      (typeof b?.error === "string" ? b.error : b?.error?.message) ??
      b?.message ??
      b?.msg ??
      (typeof b?.detail === "string" ? b.detail : b?.detail ? JSON.stringify(b.detail) : undefined) ??
      text.slice(0, 300);
    if (res.status === 401 || res.status === 403) throw new Error(`${service} didn't accept the key (${res.status}): ${why}. Paste it again in Drama → Keys.`);
    if (res.status === 402) throw new Error(`${service} says the account is out of credit (${res.status}): ${why}.`);
    if (res.status === 429) throw new Error(`${service} is rate-limiting this key (429): ${why}. Wait a minute and run again.`);
    throw new Error(`${service} refused the request (${res.status}): ${why}`);
  }
  if (body === undefined) throw new Error(`${service} sent back something that isn't JSON: ${text.slice(0, 200)}`);
  return body as T;
}

export async function poll<T>(what: string, check: () => Promise<{ done: boolean; value?: T; failed?: string; progress?: string }>, every = 5000, limitMs = 30 * 60_000): Promise<T> {
  const end = Date.now() + limitMs;
  for (;;) {
    const r = await check();
    if (r.failed) throw new Error(`${what} failed: ${r.failed}`);
    if (r.done) return r.value as T;
    if (Date.now() > end) throw new Error(`${what} took longer than ${Math.round(limitMs / 60000)} minutes. It may still finish on the service's own site.`);
    await new Promise((ok) => setTimeout(ok, every));
  }
}
