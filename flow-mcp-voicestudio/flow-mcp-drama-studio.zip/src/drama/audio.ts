import { writeFileSync } from "node:fs";
import { localVoices, speakLocally } from "../assemble.js";
import { GEMINI_VOICES, speakWithGemini } from "../gemini.js";
import { designVoice, speakWithVoiceStudio, voiceStudioCatalog } from "../voicestudio.js";
import { json } from "./http.js";
import { need } from "./keys.js";

export type VoiceProvider = "voicestudio" | "gemini" | "local" | "elevenlabs" | "openai";
export interface VoiceChoice {
  provider: VoiceProvider;
  id: string;
  name: string;
  description?: string;
}

export const VOICE_PROVIDERS: Record<VoiceProvider, { label: string; keys: string[]; paid: boolean; models: string[]; note: string }> = {
  voicestudio: { label: "VoiceStudio ✦", keys: [], paid: false, models: [], note: "Free, on this computer. Designs a matching voice for every character." },
  gemini: { label: "Google voices", keys: ["gemini"], paid: false, models: [], note: "Free tier. Same voices as Flow, acted with each line's emotion." },
  local: { label: "This computer's voices", keys: [], paid: false, models: [], note: "Free and instant; only as good as the installed voices." },
  elevenlabs: { label: "ElevenLabs", keys: ["elevenlabs"], paid: true, models: ["eleven_v4", "eleven_v3", "eleven_multilingual_v2", "eleven_flash_v2_5"], note: "Most lifelike. eleven_v3 also acts out [emotion] tags." },
  openai: { label: "OpenAI voices", keys: ["openai"], paid: true, models: ["gpt-4o-mini-tts"], note: "Directed delivery: each line is told how to sound. OpenAI retires this on 6 Jan 2027." },
};

// Dollars per 1,000 characters, roughly, for the estimate shown before a run.
export const VOICE_PRICE: Record<VoiceProvider, number> = { voicestudio: 0, gemini: 0, local: 0, elevenlabs: 0.2, openai: 0.015 };

type Wanted = { name: string; voice: string };
const female = (s: string) => /\b(female|woman|girl|she|her|lady|mother|wife|queen|grandmother)\b/i.test(s);
const male = (s: string) => /\b(male|man|boy|he|his|gentleman|father|husband|king|grandfather)\b/i.test(s) && !female(s);

// Genders of Google's 30 prebuilt voices (Google's own voice list), so a woman is never voiced by a man's voice.
const GEMINI_GENDER: Record<string, "f" | "m"> = {
  Zephyr: "f", Puck: "m", Charon: "m", Kore: "f", Fenrir: "m", Leda: "f", Orus: "m", Aoede: "f", Callirrhoe: "f", Autonoe: "f",
  Enceladus: "m", Iapetus: "m", Umbriel: "m", Algieba: "m", Despina: "f", Erinome: "f", Algenib: "m", Rasalgethi: "m", Laomedeia: "f",
  Achernar: "f", Alnilam: "m", Schedar: "m", Gacrux: "f", Pulcherrima: "f", Achird: "m", Zubenelgenubi: "m", Vindemiatrix: "f",
  Sadachbia: "m", Sadaltager: "m", Sulafat: "f",
};
const OPENAI_VOICES: { id: string; g: "f" | "m" }[] = [
  { id: "coral", g: "f" }, { id: "ash", g: "m" }, { id: "nova", g: "f" }, { id: "onyx", g: "m" }, { id: "shimmer", g: "f" }, { id: "echo", g: "m" },
  { id: "sage", g: "f" }, { id: "ballad", g: "m" }, { id: "marin", g: "f" }, { id: "cedar", g: "m" }, { id: "alloy", g: "f" }, { id: "verse", g: "m" }, { id: "fable", g: "m" },
];

// Hands out a distinct voice per character from a pool, matching gender where the description says it.
function deal<T extends { g?: "f" | "m" }>(people: Wanted[], pool: T[]): Map<string, T> {
  const used = new Set<T>();
  const out = new Map<string, T>();
  for (const p of people) {
    const g = female(p.voice) ? "f" : male(p.voice) ? "m" : undefined;
    const pick = pool.find((v) => !used.has(v) && (!g || !v.g || v.g === g)) ?? pool.find((v) => !used.has(v)) ?? pool[out.size % pool.length];
    if (!pick) throw new Error("No voices are available.");
    used.add(pick);
    out.set(p.name, pick);
  }
  return out;
}

export async function pickVoices(provider: VoiceProvider, people: Wanted[], title: string, language: string): Promise<Record<string, VoiceChoice>> {
  const out: Record<string, VoiceChoice> = {};
  if (provider === "voicestudio") {
    const have = await voiceStudioCatalog();
    if (!have.ready) throw new Error("VoiceStudio isn't running. Open it, wait for the green light, then run again.");
    for (const p of people) {
      const name = `${title} · ${p.name}`.slice(0, 80);
      const existing = have.voices.find((v) => v.name === name);
      if (existing) {
        out[p.name] = { provider, id: existing.name, name: existing.name, description: p.voice };
        continue;
      }
      // A description VoiceStudio can't map at all still gets a voice: its default one.
      const made = await designVoice({ name, description: p.voice, language }).catch(() => null);
      out[p.name] = made && "voice" in made && made.voice ? { provider, id: made.voice, name: made.voice, description: p.voice } : { provider, id: "", name: "VoiceStudio default", description: p.voice };
    }
    return out;
  }
  if (provider === "gemini") {
    const pool = GEMINI_VOICES.map((v) => ({ ...v, g: GEMINI_GENDER[v.name] }));
    for (const [n, v] of deal(people, pool)) out[n] = { provider, id: v.name, name: `${v.name} (${v.description})`, description: people.find((p) => p.name === n)!.voice };
    return out;
  }
  if (provider === "local") {
    const pool = (await localVoices()).map((v) => ({ ...v, g: /zira|hazel|susan|samantha|zoe|karen|moira|tessa|victoria|ava|allison|serena|fiona|kate|eva|jenny|aria/i.test(v.name) ? ("f" as const) : ("m" as const) }));
    if (!pool.length) throw new Error("No voices are installed on this computer.");
    for (const [n, v] of deal(people, pool)) out[n] = { provider, id: v.name, name: v.name };
    return out;
  }
  if (provider === "openai") {
    for (const [n, v] of deal(people, OPENAI_VOICES)) out[n] = { provider, id: v.id, name: v.id, description: people.find((p) => p.name === n)!.voice };
    return out;
  }
  const list = await json<{ voices: { voice_id: string; name: string; labels?: Record<string, string>; description?: string }[] }>(
    "ElevenLabs",
    await fetch("https://api.elevenlabs.io/v2/voices?page_size=100", { headers: { "xi-api-key": need("elevenlabs") } }),
  );
  const pool = list.voices.map((v) => ({ ...v, g: /female/i.test(v.labels?.gender ?? "") ? ("f" as const) : /male/i.test(v.labels?.gender ?? "") ? ("m" as const) : undefined }));
  if (!pool.length) throw new Error("This ElevenLabs account has no voices. Add some in ElevenLabs' Voice Library first.");
  for (const [n, v] of deal(people, pool)) out[n] = { provider, id: v.voice_id, name: v.name, description: people.find((p) => p.name === n)!.voice };
  return out;
}

export async function speakLine(provider: VoiceProvider, model: string | undefined, v: VoiceChoice, text: string, emotion: string, language: string, stem: string): Promise<{ file: string; seconds?: number; cost_usd?: number }> {
  if (provider === "voicestudio") {
    const said = await speakWithVoiceStudio(text, { voice: v.id || undefined, language }, stem + ".m4a");
    return { file: said.output, seconds: said.duration };
  }
  if (provider === "gemini") {
    const said = await speakWithGemini(text, v.id, stem + ".m4a", `${emotion}${v.description ? `, as ${v.description}` : ""}`);
    return { file: said.output, seconds: said.duration };
  }
  if (provider === "local") {
    const said = await speakLocally(text, v.id, stem + ".m4a");
    return { file: said.output, seconds: said.duration };
  }
  const cost_usd = (text.length / 1000) * VOICE_PRICE[provider];
  if (provider === "openai") {
    const res = await fetch("https://api.openai.com/v1/audio/speech", {
      method: "POST",
      headers: { authorization: `Bearer ${need("openai")}`, "content-type": "application/json" },
      body: JSON.stringify({
        model: model ?? "gpt-4o-mini-tts",
        voice: v.id,
        input: text,
        instructions: `Act this line ${emotion}.${v.description ? ` The speaker: ${v.description}.` : ""} Natural, dramatic, not narrated.`,
        response_format: "mp3",
      }),
    });
    if (!res.ok) await json("OpenAI", res);
    writeFileSync(stem + ".mp3", Buffer.from(await res.arrayBuffer()));
    return { file: stem + ".mp3", cost_usd };
  }
  const m = model ?? "eleven_v4";
  // eleven_v3 reads bracketed audio tags as direction; the older models would speak them aloud.
  const said = m === "eleven_v3" && emotion ? `[${emotion}] ${text}` : text;
  const res = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(v.id)}?output_format=mp3_44100_128`, {
    method: "POST",
    headers: { "xi-api-key": need("elevenlabs"), "content-type": "application/json", accept: "audio/mpeg" },
    // multilingual_v2 refuses language_code; the others take it.
    body: JSON.stringify({ text: said, model_id: m, ...(m === "eleven_multilingual_v2" ? {} : { language_code: language.slice(0, 2) }) }),
  });
  if (!res.ok) await json("ElevenLabs", res);
  writeFileSync(stem + ".mp3", Buffer.from(await res.arrayBuffer()));
  return { file: stem + ".mp3", cost_usd };
}

export async function makeSound(prompt: string, seconds: number, stem: string) {
  const res = await fetch("https://api.elevenlabs.io/v1/sound-generation?output_format=mp3_44100_128", {
    method: "POST",
    headers: { "xi-api-key": need("elevenlabs"), "content-type": "application/json", accept: "audio/mpeg" },
    body: JSON.stringify({ text: prompt, duration_seconds: Math.max(0.5, Math.min(30, seconds)), prompt_influence: 0.4 }),
  });
  if (!res.ok) await json("ElevenLabs", res);
  writeFileSync(stem + ".mp3", Buffer.from(await res.arrayBuffer()));
  return { file: stem + ".mp3", cost_usd: 0.05 };
}

export async function makeMusic(prompt: string, seconds: number, stem: string) {
  const res = await fetch("https://api.elevenlabs.io/v1/music?output_format=mp3_44100_128", {
    method: "POST",
    headers: { "xi-api-key": need("elevenlabs"), "content-type": "application/json", accept: "audio/mpeg" },
    body: JSON.stringify({ prompt: `${prompt}. Instrumental underscore for a drama, no vocals.`, music_length_ms: Math.max(10_000, Math.min(300_000, seconds * 1000)), force_instrumental: true, model_id: "music_v2_5" }),
  });
  if (!res.ok) await json("ElevenLabs", res);
  writeFileSync(stem + ".mp3", Buffer.from(await res.arrayBuffer()));
  return { file: stem + ".mp3", cost_usd: Math.max(0.3, (seconds / 60) * 0.8) };
}
