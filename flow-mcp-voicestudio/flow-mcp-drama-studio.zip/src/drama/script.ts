import Anthropic from "@anthropic-ai/sdk";
import { betaZodOutputFormat } from "@anthropic-ai/sdk/helpers/beta/zod";
import { z } from "zod";
import { geminiKey } from "../gemini.js";
import { need } from "./keys.js";

// One micro-drama episode. The writer fills it in; every later stage reads it. Kept free of numeric limits because the
// writers' structured-output modes reject them; clean() puts every number in range afterwards.
export const ScriptSchema = z.object({
  title: z.string(),
  logline: z.string().describe("One sentence: who wants what, and what stands in the way."),
  genre: z.string(),
  language: z.string().describe("ISO code of the dialogue, e.g. en, es, yo, pt."),
  visual_style: z
    .string()
    .describe("One look for every image and shot: medium (photoreal, anime, 3D animation...), palette, lighting, lens, era. Repeated in every image prompt."),
  hook: z.string().describe("What grabs the viewer in the first three seconds."),
  cliffhanger: z.string().describe("The unresolved moment the episode ends on."),
  characters: z
    .array(
      z.object({
        name: z.string(),
        role: z.string().describe("protagonist, rival, love interest, villain..."),
        look: z
          .string()
          .describe("Exact, reusable appearance: age, ethnicity, face, hair, build, and one signature outfit with colours. Detailed enough to redraw the same person every time."),
        personality: z.string(),
        voice: z.string().describe("How they sound, in plain words: gender, age, pitch, accent, pace, e.g. 'female, young adult, high pitch, british accent, quick'."),
      }),
    )
    .describe("2 to 5 characters."),
  scenes: z
    .array(
      z.object({
        location: z.string(),
        characters: z.array(z.string()).describe("Names of the characters on screen, exactly as in characters[]."),
        image_prompt: z
          .string()
          .describe("The key frame as a still image: shot size and angle, who is where doing what, expressions, setting details, light. No dialogue, no text on screen."),
        motion_prompt: z.string().describe("What moves during the shot and the camera move, e.g. 'she slams the phone down and turns; slow push-in'."),
        seconds: z.number().describe("Shot length, 4 to 10 seconds, long enough for its dialogue."),
        dialogue: z
          .array(z.object({ character: z.string(), line: z.string(), emotion: z.string().describe("one word: angry, whispering, tearful, smug...") }))
          .describe("Spoken lines in this shot, in order. Short: about 2.5 words a second must fit the shot."),
        narration: z.string().describe("Optional voice-over for this shot; empty string for none."),
        sound: z.string().describe("Sound effect for the shot, e.g. 'rain on a window'; empty string for none."),
      }),
    )
    .describe("The episode's shots in order."),
  music: z.string().describe("Background music in one line: genre, mood, tempo, instruments."),
});
export type Script = z.infer<typeof ScriptSchema>;

export interface Brief {
  title: string;
  idea: string;
  genre?: string;
  style?: string;
  language?: string;
  scenes?: number;
  seconds?: number;
  audience?: string;
}

const prompt = (b: Brief) => {
  const shots = b.scenes ?? Math.round((b.seconds ?? 60) / 7);
  return [
    `Write one episode of a vertical (9:16) micro-drama for phone viewers, ready to be filmed shot by shot by AI image and video generators.`,
    `Title: ${b.title}`,
    `Idea: ${b.idea}`,
    b.genre ? `Genre: ${b.genre}` : "",
    b.style ? `Visual style: ${b.style}` : "",
    `Dialogue language: ${b.language ?? "en"}`,
    b.audience ? `Audience: ${b.audience}` : "",
    `Length: about ${b.seconds ?? 60} seconds in ${shots} shots of 4 to 10 seconds each.`,
    ``,
    `Micro-drama rules: open on the hook in the first shot; heightened emotion, a reversal or reveal every few shots; end on a cliffhanger.`,
    `Keep lines short and punchy, at most about 2.5 words per second of the shot they're in. Every shot is one continuous camera take in one place.`,
    `Describe characters so precisely that an image generator draws the same person every time, and keep their outfits fixed for the episode.`,
    `Image prompts describe one frozen moment and never ask for written text, captions or logos.`,
  ]
    .filter(Boolean)
    .join("\n");
};

export const WRITERS = {
  anthropic: { label: "Claude (Anthropic key)", models: ["claude-opus-5-5", "claude-sonnet-5-5", "claude-haiku-5-5"] },
  openai: { label: "OpenAI", models: ["gpt-6-astra", "gpt-6.1-sol", "gpt-6-luna"] },
  gemini: { label: "Gemini", models: ["gemini-4-argon", "gemini-3.8-flash"] },
  chat: { label: "Claude in chat (no key)", models: [] as string[] },
} as const;
export type Writer = keyof typeof WRITERS;

export async function writeScript(writer: Writer, model: string | undefined, b: Brief): Promise<Script> {
  if (writer === "chat") throw new Error("This drama is written in chat: ask Claude to write it (flow_drama_script), or pick another writer.");
  const raw = writer === "anthropic" ? await withClaude(model, b) : writer === "openai" ? await withOpenAI(model, b) : await withGemini(model, b);
  return clean(ScriptSchema.parse(raw), b);
}

async function withClaude(model: string | undefined, b: Brief) {
  const client = new Anthropic({ apiKey: need("anthropic") });
  try {
    const res = await client.beta.messages.parse({
      model: model ?? "claude-opus-5-5",
      max_tokens: 16000,
      output_config: { effort: "high", format: betaZodOutputFormat(ScriptSchema) },
      // On a policy decline the API re-runs the request on a fallback model by itself instead of failing the episode.
      betas: ["server-side-fallback-2026-07-01"],
      fallbacks: "default",
      system: "You are a head writer for a hit vertical micro-drama studio. You write tight, emotional, highly visual episodes.",
      messages: [{ role: "user", content: prompt(b) }],
    });
    if (res.stop_reason === "refusal") throw new Error(`Claude declined to write this one${res.stop_details?.explanation ? `: ${res.stop_details.explanation}` : ""}. Try rewording the idea.`);
    if (res.stop_reason === "max_tokens") throw new Error("The script ran out of room. Ask for fewer shots and try again.");
    if (!res.parsed_output) throw new Error("Claude's script didn't match the format. Try again.");
    return res.parsed_output;
  } catch (err) {
    if (err instanceof Anthropic.AuthenticationError) throw new Error("Anthropic didn't accept the key. Paste it again in Drama → Keys.");
    if (err instanceof Anthropic.RateLimitError) throw new Error("Anthropic is rate-limiting this key. Wait a minute and try again.");
    if (err instanceof Anthropic.APIError) throw new Error(`Anthropic refused the request (${err.status}): ${err.message}`);
    throw err;
  }
}

// The JSON Schema both other writers take, made from the same Zod schema so all three agree.
const jsonSchema = () => z.toJSONSchema(ScriptSchema, { target: "draft-7" }) as Record<string, unknown>;

async function withOpenAI(model: string | undefined, b: Brief) {
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { authorization: `Bearer ${need("openai")}`, "content-type": "application/json" },
    body: JSON.stringify({
      model: model ?? "gpt-6-astra",
      messages: [
        { role: "system", content: "You are a head writer for a hit vertical micro-drama studio. You write tight, emotional, highly visual episodes." },
        { role: "user", content: prompt(b) },
      ],
      response_format: { type: "json_schema", json_schema: { name: "episode", strict: true, schema: strictify(jsonSchema()) } },
    }),
  });
  const body = (await res.json()) as { error?: { message?: string }; choices?: { message?: { content?: string; refusal?: string } }[] };
  if (!res.ok) throw new Error(`OpenAI refused the request (${res.status}): ${body.error?.message ?? "no detail"}`);
  const msg = body.choices?.[0]?.message;
  if (msg?.refusal) throw new Error(`OpenAI declined to write this one: ${msg.refusal}`);
  return JSON.parse(msg?.content ?? "{}");
}

// OpenAI's strict mode wants every property required and no extra keys, at every level.
function strictify(s: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = { ...s };
  delete out.$schema;
  if (out.type === "object" && out.properties) {
    const props = out.properties as Record<string, Record<string, unknown>>;
    out.properties = Object.fromEntries(Object.entries(props).map(([k, v]) => [k, strictify(v)]));
    out.required = Object.keys(props);
    out.additionalProperties = false;
  }
  if (out.items) out.items = strictify(out.items as Record<string, unknown>);
  return out;
}

async function withGemini(model: string | undefined, b: Brief) {
  const k = geminiKey() ?? need("gemini");
  const schema = strictify(jsonSchema());
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model ?? "gemini-4-argon"}:generateContent`, {
    method: "POST",
    headers: { "x-goog-api-key": k, "content-type": "application/json" },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: "You are a head writer for a hit vertical micro-drama studio. You write tight, emotional, highly visual episodes." }] },
      contents: [{ role: "user", parts: [{ text: prompt(b) }] }],
      generationConfig: { responseMimeType: "application/json", responseJsonSchema: schema },
    }),
  });
  const body = (await res.json()) as { error?: { message?: string }; candidates?: { content?: { parts?: { text?: string }[] }; finishReason?: string }[] };
  if (!res.ok) throw new Error(`Gemini refused the request (${res.status}): ${body.error?.message ?? "no detail"}`);
  const text = body.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("") ?? "";
  if (!text) throw new Error(`Gemini returned no script (${body.candidates?.[0]?.finishReason ?? "no reason given"}).`);
  return JSON.parse(text);
}

// Whatever the writer returned, the rest of the pipeline gets sane values: known character names, 4-10 s shots that
// fit their own dialogue, no empty scenes.
export function clean(s: Script, b?: Partial<Brief>): Script {
  const names = new Map(s.characters.map((c) => [c.name.toLowerCase(), c.name]));
  const fix = (n: string) => names.get(n.trim().toLowerCase()) ?? n.trim();
  const scenes = s.scenes
    .filter((sc) => sc.image_prompt?.trim())
    .map((sc) => {
      const words = [...sc.dialogue.map((d) => d.line), sc.narration ?? ""].join(" ").split(/\s+/).filter(Boolean).length;
      const need = Math.ceil(words / 2.5) + 1;
      return {
        ...sc,
        characters: sc.characters.map(fix),
        dialogue: sc.dialogue.filter((d) => d.line?.trim()).map((d) => ({ ...d, character: fix(d.character) })),
        narration: sc.narration?.trim() ?? "",
        sound: sc.sound?.trim() ?? "",
        seconds: Math.min(10, Math.max(4, Math.round(Math.max(Number(sc.seconds) || 6, need)))),
      };
    });
  if (!scenes.length) throw new Error("The script has no shots.");
  if (!s.characters.length) throw new Error("The script has no characters.");
  return { ...s, title: s.title?.trim() || b?.title || "Untitled", language: s.language || b?.language || "en", scenes };
}
