import { key, type KeyName } from "./keys.js";
import { IMAGE_PROVIDERS, imagePrice, makeImage, type ImageProvider } from "./images.js";
import { VIDEO_PROVIDERS, videoPrice, makeVideo, type VideoProvider } from "./video.js";
import { VOICE_PRICE, VOICE_PROVIDERS, makeMusic, makeSound, pickVoices, speakLine, type VoiceChoice, type VoiceProvider } from "./audio.js";
import type { Writer } from "./script.js";

export { IMAGE_PROVIDERS, VIDEO_PROVIDERS, VOICE_PROVIDERS, makeImage, makeVideo, makeMusic, makeSound, pickVoices, speakLine };
export type { ImageProvider, VideoProvider, VoiceProvider, VoiceChoice };

const ready = (keys: readonly string[]) => keys.every((k) => Boolean(key(k as KeyName)));

// Everything the panel's pickers and flow_drama_providers show, with whether this computer has the keys for it.
export function catalog() {
  const tag = <T extends { keys: readonly string[]; available?: false }>(table: Record<string, T>) =>
    Object.fromEntries(Object.entries(table).map(([id, p]) => [id, { ...p, ready: p.available !== false && (id === "kling" ? Boolean(key("kling") || (key("kling_access") && key("kling_secret"))) : ready(p.keys)) }]));
  return { image: tag(IMAGE_PROVIDERS), video: tag(VIDEO_PROVIDERS), voice: tag(VOICE_PROVIDERS) };
}

// Writing an episode is one long request: a rough price per writer.
const WRITER_USD: Record<Writer, number> = { anthropic: 0.25, openai: 0.3, gemini: 0.1, chat: 0 };

export function estimate(a: {
  writer?: Writer;
  image: { id: ImageProvider; model?: string };
  images: number;
  video: { id: VideoProvider; model?: string };
  shot_seconds: number;
  shots: number;
  voice: { id: VoiceProvider };
  voice_chars: number;
  sounds: number;
  music: number;
  max_credits: number;
}) {
  const lines: string[] = [];
  let usd = 0;
  let flow_credits = 0;
  const add = (what: string, cost: number) => {
    if (cost > 0.001) {
      usd += cost;
      lines.push(`${what} ~$${cost.toFixed(2)}`);
    }
  };
  if (a.writer) add("script", WRITER_USD[a.writer]);
  if (a.images) {
    if (a.image.id === "flow") lines.push(`${a.images} image(s) on Flow, free`);
    else add(`${a.images} image(s) on ${IMAGE_PROVIDERS[a.image.id].label}`, a.images * imagePrice(a.image.id, a.image.model));
  }
  if (a.shots) {
    if (a.video.id === "flow") {
      flow_credits = a.shots * a.max_credits;
      lines.push(`${a.shots} shot(s) on Flow, at most ${a.max_credits} credits each (usually 7-15)`);
    } else add(`${a.shots} shot(s), ${a.shot_seconds} s on ${VIDEO_PROVIDERS[a.video.id].label}`, videoPrice(a.video.id, a.video.model, a.shot_seconds, a.shots));
  }
  if (a.voice_chars) {
    const cost = (a.voice_chars / 1000) * VOICE_PRICE[a.voice.id];
    if (cost > 0.001) add(`voices on ${VOICE_PROVIDERS[a.voice.id].label}`, cost);
    else lines.push(`voices on ${VOICE_PROVIDERS[a.voice.id].label}, free`);
  }
  if (a.sounds) add(`${a.sounds} sound effect(s) on ElevenLabs`, a.sounds * 0.05);
  if (a.music) add("music on ElevenLabs", 0.8);
  return { usd: Number(usd.toFixed(2)), flow_credits, lines, note: "Estimates from each service's list prices; your plan's real price may differ." };
}
