import { chmodSync, existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { HOME_DIR } from "../chrome.js";
import { geminiKey, saveGeminiKey } from "../gemini.js";

// Every paid service the Drama Studio can use, with where its key comes from. Keys are typed into the Flow Studio panel
// only and saved in a file only this user can read; no MCP tool can read or write them, so a key never enters a chat.
// An environment variable of the usual name works too and wins over the file.
export const KEY_SPECS = {
  anthropic: { label: "Anthropic (Claude)", env: "ANTHROPIC_API_KEY", url: "https://console.anthropic.com/settings/keys", used_for: "writing" },
  openai: { label: "OpenAI", env: "OPENAI_API_KEY", url: "https://platform.openai.com/api-keys", used_for: "writing, images, voices" },
  gemini: { label: "Google AI Studio (Gemini, Veo)", env: "GEMINI_API_KEY", url: "https://aistudio.google.com/apikey", used_for: "writing, images, video, voices" },
  fal: { label: "fal.ai", env: "FAL_KEY", url: "https://fal.ai/dashboard/keys", used_for: "images, video (Kling, Hailuo, Seedance, Wan, Veo)" },
  openrouter: { label: "OpenRouter", env: "OPENROUTER_API_KEY", url: "https://openrouter.ai/settings/keys", used_for: "images" },
  runway: { label: "Runway", env: "RUNWAYML_API_SECRET", url: "https://dev.runwayml.com/", used_for: "video" },
  kling: { label: "Kling API key", env: "KLING_API_KEY", url: "https://app.klingai.com/global/dev/api-key", used_for: "video" },
  kling_access: { label: "Kling access key (older accounts)", env: "KLING_ACCESS_KEY", url: "https://app.klingai.com/global/dev/api-key", used_for: "video" },
  kling_secret: { label: "Kling secret key (older accounts)", env: "KLING_SECRET_KEY", url: "https://app.klingai.com/global/dev/api-key", used_for: "video" },
  higgsfield_key: { label: "Higgsfield API key", env: "HIGGSFIELD_API_KEY", url: "https://console.higgsfield.ai/", used_for: "video" },
  higgsfield_secret: { label: "Higgsfield API secret", env: "HIGGSFIELD_API_SECRET", url: "https://console.higgsfield.ai/", used_for: "video" },
  elevenlabs: { label: "ElevenLabs", env: "ELEVENLABS_API_KEY", url: "https://elevenlabs.io/app/settings/api-keys", used_for: "voices, sound effects, music" },
} as const;
export type KeyName = keyof typeof KEY_SPECS;

const FILE = join(HOME_DIR, "keys.json");

function stored(): Partial<Record<KeyName, string>> {
  try {
    return existsSync(FILE) ? (JSON.parse(readFileSync(FILE, "utf8")) as Partial<Record<KeyName, string>>) : {};
  } catch {
    return {};
  }
}

export function key(name: KeyName): string | undefined {
  if (name === "gemini") return geminiKey();
  const v = (process.env[KEY_SPECS[name].env] ?? stored()[name] ?? "").trim();
  return v.length >= 8 ? v : undefined;
}

export function need(name: KeyName): string {
  const k = key(name);
  if (!k) {
    const s = KEY_SPECS[name];
    throw new Error(`No ${s.label} key yet. Get one at ${s.url}, then paste it into Flow Studio → Drama → Keys → ${s.label} → Save. Never paste keys into a chat.`);
  }
  return k;
}

// What the panel and Claude may see: which keys exist and their last four characters, never the keys.
export function keyStatus() {
  return Object.fromEntries(
    (Object.keys(KEY_SPECS) as KeyName[]).map((n) => {
      const k = key(n);
      const from = !k ? undefined : n === "gemini" ? "saved" : process.env[KEY_SPECS[n].env] ? "environment" : "saved";
      return [n, { ...KEY_SPECS[n], set: Boolean(k), ending: k?.slice(-4), from }];
    }),
  );
}

// Panel only. An empty value removes a saved key. Gemini keeps its own checked-with-Google file, shared with Voice.
export async function saveKey(name: KeyName, raw: string) {
  if (!(name in KEY_SPECS)) throw new Error(`Unknown key "${name}".`);
  const value = raw.trim();
  if (name === "gemini") {
    if (!value) throw new Error("Paste the Google AI Studio key first.");
    return saveGeminiKey(value);
  }
  if (value && (!/^[\x21-\x7e]{8,512}$/.test(value) || /^(YOUR|PASTE|<|\$)/i.test(value))) {
    throw new Error(`That doesn't look like a ${KEY_SPECS[name].label} key. Copy the whole key, with no spaces.`);
  }
  const all = stored();
  if (value) all[name] = value;
  else delete all[name];
  mkdirSync(dirname(FILE), { recursive: true });
  writeFileSync(FILE, JSON.stringify(all, null, 2), { mode: 0o600 });
  chmodSync(FILE, 0o600);
  return { saved: Boolean(value), name, ending: value ? value.slice(-4) : undefined };
}
