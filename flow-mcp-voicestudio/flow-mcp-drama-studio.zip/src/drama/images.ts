import { readFileSync, writeFileSync } from "node:fs";
import { basename } from "node:path";
import { geminiKey } from "../gemini.js";
import { b64, dataUri, download, json, mimeOf, saveDataUri } from "./http.js";
import { need } from "./keys.js";

export type ImageProvider = "flow" | "gemini" | "openai" | "fal" | "openrouter";

export const IMAGE_PROVIDERS: Record<ImageProvider, { label: string; keys: string[]; paid: boolean; models: { id: string; label: string; usd: number }[]; note: string }> = {
  flow: { label: "Google Flow", keys: [], paid: false, models: [{ id: "flow", label: "Nano Banana in Flow", usd: 0 }], note: "Free. Characters become Flow characters, so every frame stays on-model." },
  gemini: {
    label: "Gemini API",
    keys: ["gemini"],
    paid: true,
    models: [
      { id: "gemini-nano-banana-2.1", label: "Nano Banana 2.1", usd: 0.04 },
      { id: "gemini-3-pro-image", label: "Nano Banana Pro", usd: 0.14 },
      { id: "gemini-3.1-flash-image", label: "Nano Banana 2", usd: 0.04 },
      { id: "gemini-3.1-flash-lite-image", label: "Nano Banana 2 Lite (cheapest)", usd: 0.02 },
    ],
    note: "Up to 5 character references per frame.",
  },
  openai: {
    label: "OpenAI",
    keys: ["openai"],
    paid: true,
    models: [
      { id: "gpt-image-2.5-flare", label: "GPT Image 2.5 Flare (fast)", usd: 0.05 },
      { id: "gpt-image-2.5-sunburst", label: "GPT Image 2.5 Sunburst (most precise)", usd: 0.12 },
      { id: "gpt-image-2", label: "GPT Image 2", usd: 0.07 },
    ],
    note: "Portrait 1024×1536. Character references through image edits.",
  },
  fal: {
    label: "fal.ai",
    keys: ["fal"],
    paid: true,
    models: [
      { id: "fal-ai/nano-banana-2.1", label: "Nano Banana 2.1", usd: 0.04 },
      { id: "fal-ai/flux-3-image", label: "FLUX 3", usd: 0.05 },
      { id: "fal-ai/nano-banana-pro", label: "Nano Banana Pro", usd: 0.15 },
    ],
    note: "One key for many image models; references go through each model's edit endpoint.",
  },
  openrouter: {
    label: "OpenRouter",
    keys: ["openrouter"],
    paid: true,
    models: [
      { id: "google/gemini-nano-banana-2.1", label: "Nano Banana 2.1", usd: 0.04 },
      { id: "openai/gpt-image-2.5-flare", label: "GPT Image 2.5 Flare", usd: 0.05 },
      { id: "black-forest-labs/flux-3-image", label: "FLUX 3", usd: 0.05 },
      { id: "bytedance-seed/seedream-5-0-pro", label: "Seedream 5 Pro", usd: 0.04 },
      { id: "google/gemini-3-pro-image", label: "Nano Banana Pro", usd: 0.14 },
    ],
    note: "Pay-as-you-go access to many image models with one key.",
  },
};

export const imagePrice = (p: ImageProvider, model?: string) => IMAGE_PROVIDERS[p].models.find((m) => m.id === model)?.usd ?? IMAGE_PROVIDERS[p].models[0].usd;

// One vertical image from a prompt, drawing the people in `refs` (local portrait files) as they look there.
export async function makeImage(p: Exclude<ImageProvider, "flow">, model: string | undefined, prompt: string, refs: string[], stem: string): Promise<{ file: string; cost_usd: number }> {
  const m = model ?? IMAGE_PROVIDERS[p].models[0].id;
  const cost_usd = imagePrice(p, m);
  const file = p === "gemini" ? await gemini(m, prompt, refs, stem) : p === "openai" ? await openai(m, prompt, refs, stem) : p === "fal" ? await fal(m, prompt, refs, stem) : await openrouter(m, prompt, refs, stem);
  return { file, cost_usd };
}

async function gemini(model: string, prompt: string, refs: string[], stem: string) {
  const k = geminiKey() ?? need("gemini");
  const body = await json<{ candidates?: { content?: { parts?: { inlineData?: { mimeType?: string; data?: string }; text?: string }[] }; finishReason?: string }[] }>(
    "Gemini",
    await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
      method: "POST",
      headers: { "x-goog-api-key": k, "content-type": "application/json" },
      body: JSON.stringify({
        contents: [{ role: "user", parts: [...refs.slice(0, 5).map((r) => ({ inlineData: { mimeType: mimeOf(r), data: b64(r) } })), { text: prompt }] }],
        generationConfig: { responseModalities: ["IMAGE"], imageConfig: { aspectRatio: "9:16" } },
      }),
    }),
  );
  const part = body.candidates?.[0]?.content?.parts?.find((x) => x.inlineData?.data);
  if (!part?.inlineData?.data) throw new Error(`Gemini made no image (${body.candidates?.[0]?.finishReason ?? "no reason given"}). Try rewording the scene.`);
  return saveDataUri(`data:${part.inlineData.mimeType ?? "image/png"};base64,${part.inlineData.data}`, stem);
}

async function openai(model: string, prompt: string, refs: string[], stem: string) {
  const auth = { authorization: `Bearer ${need("openai")}` };
  let res: Response;
  if (refs.length) {
    const form = new FormData();
    form.append("model", model);
    form.append("prompt", prompt);
    form.append("size", "1024x1536");
    for (const r of refs.slice(0, 4)) form.append("image[]", new Blob([readFileSync(r)], { type: mimeOf(r) }), basename(r));
    res = await fetch("https://api.openai.com/v1/images/edits", { method: "POST", headers: auth, body: form });
  } else {
    res = await fetch("https://api.openai.com/v1/images/generations", {
      method: "POST",
      headers: { ...auth, "content-type": "application/json" },
      body: JSON.stringify({ model, prompt, size: "1024x1536", n: 1 }),
    });
  }
  const body = await json<{ data?: { b64_json?: string; url?: string }[] }>("OpenAI", res);
  const img = body.data?.[0];
  if (img?.b64_json) {
    writeFileSync(stem + ".png", Buffer.from(img.b64_json, "base64"));
    return stem + ".png";
  }
  if (img?.url) return download(img.url, stem, ".png");
  throw new Error("OpenAI made no image.");
}

async function fal(model: string, prompt: string, refs: string[], stem: string) {
  // Reference-taking models live at their /edit endpoint; fal takes data URIs wherever it takes an image URL.
  const input: Record<string, unknown> = { prompt, num_images: 1, aspect_ratio: "9:16", output_format: "png" };
  if (refs.length) input.image_urls = refs.slice(0, 5).map(dataUri);
  const body = await json<{ images?: { url: string }[] }>(
    "fal.ai",
    await fetch(`https://fal.run/${refs.length ? `${model}/edit` : model}`, {
      method: "POST",
      headers: { authorization: `Key ${need("fal")}`, "content-type": "application/json" },
      body: JSON.stringify(input),
      signal: AbortSignal.timeout(5 * 60_000),
    }),
  );
  const url = body.images?.[0]?.url;
  if (!url) throw new Error("fal.ai made no image.");
  return url.startsWith("data:") ? saveDataUri(url, stem) : download(url, stem, ".png");
}

async function openrouter(model: string, prompt: string, refs: string[], stem: string) {
  const body = await json<{ data?: { b64_json?: string; media_type?: string }[]; usage?: { cost?: number } }>(
    "OpenRouter",
    await fetch("https://openrouter.ai/api/v1/images", {
      method: "POST",
      headers: { authorization: `Bearer ${need("openrouter")}`, "content-type": "application/json", "x-title": "Flow Drama Studio" },
      body: JSON.stringify({
        model,
        prompt,
        aspect_ratio: "9:16",
        n: 1,
        output_format: "png",
        ...(refs.length ? { input_references: refs.slice(0, 5).map((r) => ({ type: "image_url", image_url: { url: dataUri(r) } })) } : {}),
      }),
      signal: AbortSignal.timeout(5 * 60_000),
    }),
  );
  const img = body.data?.[0];
  if (!img?.b64_json) throw new Error("OpenRouter made no image.");
  return saveDataUri(`data:${img.media_type ?? "image/png"};base64,${img.b64_json}`, stem);
}
