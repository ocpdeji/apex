import { execFile } from "node:child_process";
import { createHmac } from "node:crypto";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { promisify } from "node:util";
import { geminiKey } from "../gemini.js";
import { download, json, poll } from "./http.js";
import { key, need } from "./keys.js";

const run = promisify(execFile);
const FFMPEG = process.env.FLOW_MCP_FFMPEG ?? "ffmpeg";

export type VideoProvider = "flow" | "fal" | "veo" | "runway" | "kling" | "higgsfield" | "openart";

// How long a model's shots can be: a list of exact lengths or a range of whole seconds.
type Lengths = number[] | { min: number; max: number };
interface VideoModel {
  id: string;
  label: string;
  usd: number;
  per: "second";
  lengths: Lengths;
}

const m = (id: string, label: string, usd: number, lengths: Lengths): VideoModel => ({ id, label, usd, per: "second", lengths });

export const VIDEO_PROVIDERS: Record<VideoProvider, { label: string; keys: string[]; paid: boolean; models: VideoModel[]; note: string; available?: false }> = {
  flow: { label: "Google Flow", keys: [], paid: true, models: [], note: "Uses your Flow credits (about 7-15 a shot on Omni 1.1 Flash). Pick the Flow model in the Shots tab's list, e.g. Omni 1.1 Flash or Veo 3.1 - Fast." },
  fal: {
    label: "fal.ai",
    keys: ["fal"],
    paid: true,
    models: [
      m("kling/v4/image-to-video", "Kling 4.0 · 720p", 0.157, { min: 3, max: 30 }),
      m("fal-ai/kling-video/v3/pro/image-to-video", "Kling 3.0 Pro", 0.112, { min: 3, max: 15 }),
      m("minimax/h3/image-to-video", "MiniMax Hailuo H3 · 768P", 0.06, { min: 5, max: 15 }),
      m("bytedance/seedance-2.5/us/image-to-video", "Seedance 2.5 · 720p", 0.473, { min: 4, max: 30 }),
      m("bytedance/seedance-2.0/image-to-video", "Seedance 2.0 · 720p", 0.303, { min: 4, max: 15 }),
      m("alibaba/wan-3.0/image-to-video", "Wan 3.0 · 720p", 0.1, { min: 2, max: 30 }),
      m("google/gemini-omni-flash/v1.1/image-to-video", "Google Gemini Omni Flash · 720p", 0.1, { min: 3, max: 10 }),
      m("fal-ai/veo3.1/fast/image-to-video", "Veo 3.1 Fast (may be retired)", 0.1, [4, 6, 8]),
    ],
    note: "One key for Kling, Hailuo, Seedance, Wan and Google's models.",
  },
  veo: {
    label: "Google (Gemini API)",
    keys: ["gemini"],
    paid: true,
    models: [m("gemini-omni-1.1-flash", "Gemini Omni Flash · 720p (Veo's successor)", 0.1, [8])],
    note: "Google retired the Veo previews on 22 Oct 2026; Gemini Omni Flash replaces them. Shot length is chosen by the model.",
  },
  runway: {
    label: "Runway",
    keys: ["runway"],
    paid: true,
    models: [
      m("gen4.5", "Runway Gen-4.5", 0.12, { min: 2, max: 10 }),
      m("gen4_turbo", "Runway Gen-4 Turbo (cheapest)", 0.05, { min: 2, max: 10 }),
      m("kling3.0_pro", "Kling 3.0 Pro via Runway", 0.12, { min: 3, max: 15 }),
      m("seedance2_5", "Seedance 2.5 via Runway · 720p", 0.3, { min: 4, max: 15 }),
      m("wan3", "Wan 3 via Runway · 720p", 0.1, { min: 2, max: 30 }),
      m("veo3.1_fast", "Veo 3.1 Fast via Runway", 0.1, [4, 6, 8]),
    ],
    note: "Runway's own models plus Kling, Seedance, Wan and Veo on one Runway key.",
  },
  kling: {
    label: "Kling AI",
    keys: ["kling"],
    paid: true,
    models: [m("kling-3.0", "Kling 3.0 · 720p", 0.084, { min: 3, max: 15 }), m("kling-4.0", "Kling 4.0 (not open on Kling's API yet)", 0.157, { min: 3, max: 30 })],
    note: "Kling's own API with a Kling API key. Kling 4.0 is already available through fal.",
  },
  higgsfield: {
    label: "Higgsfield",
    keys: ["higgsfield_key", "higgsfield_secret"],
    paid: true,
    models: [
      m("bytedance/seedance-2.5/image-to-video", "Seedance 2.5 · 720p", 0.47, { min: 4, max: 30 }),
      m("kling-video/v3.0/pro/image-to-video", "Kling 3.0 Pro", 0.12, { min: 3, max: 15 }),
    ],
    note: "Higgsfield's API key ID and secret. Prices are approximate; Higgsfield bills in its own credits.",
  },
  openart: {
    label: "OpenArt (no API)",
    keys: [],
    paid: true,
    available: false,
    models: [],
    note: "OpenArt has no public API for apps like this one; it only offers a sign-in connector for chat apps. The same models (Seedance, Wan, Kling, Veo, MiniMax) are available here through fal, Runway or Higgsfield.",
  },
};

const modelOf = (p: VideoProvider, id?: string) => VIDEO_PROVIDERS[p].models.find((x) => x.id === id) ?? VIDEO_PROVIDERS[p].models[0];

export function fit(lengths: Lengths, want: number): number {
  if (Array.isArray(lengths)) return lengths.find((x) => x >= want) ?? lengths[lengths.length - 1];
  return Math.min(lengths.max, Math.max(lengths.min, Math.ceil(want)));
}

export function videoPrice(p: VideoProvider, model: string | undefined, seconds: number, shots: number) {
  if (p === "flow" || p === "openart") return 0;
  const mm = modelOf(p, model);
  // Each shot is rounded up to a length the model can make.
  const each = shots ? seconds / shots : 0;
  return mm.usd * fit(mm.lengths, each) * shots;
}

// Frames are re-encoded as a modest JPEG first: every service has an upload limit (Runway takes 5 MB as a data URI).
async function jpeg(frame: string) {
  const out = frame.replace(/\.\w+$/, "") + ".upload.jpg";
  if (!existsSync(out)) await run(FFMPEG, ["-v", "error", "-y", "-i", frame, "-vf", "scale='min(1080,iw)':-2", "-q:v", "3", out]);
  return out;
}
const jpegUri = async (frame: string) => `data:image/jpeg;base64,${readFileSync(await jpeg(frame)).toString("base64")}`;

export async function makeVideo(p: VideoProvider, model: string | undefined, prompt: string, frame: string, seconds: number, stem: string): Promise<{ file: string; cost_usd: number; seconds: number }> {
  if (p === "flow") throw new Error("Flow shots are made through Flow itself.");
  if (p === "openart") throw new Error(VIDEO_PROVIDERS.openart.note);
  const mm = modelOf(p, model);
  const len = fit(mm.lengths, seconds);
  const file = p === "fal" ? await fal(mm.id, prompt, frame, len, stem) : p === "veo" ? await veo(mm.id, prompt, frame, stem) : p === "runway" ? await runway(mm.id, prompt, frame, len, stem) : p === "kling" ? await kling(mm.id, prompt, frame, len, stem) : await higgsfield(mm.id, prompt, frame, len, stem);
  return { file, cost_usd: mm.usd * len, seconds: len };
}

async function fal(model: string, prompt: string, frame: string, len: number, stem: string) {
  const image = await jpegUri(frame);
  // Each family names its fields its own way; dialogue and sound are added afterwards, so models' own audio stays off.
  const input: Record<string, unknown> = { prompt };
  if (model.startsWith("kling/v4")) Object.assign(input, { start_image_url: image, duration: len, resolution: "720p" });
  else if (model.includes("kling-video/v3")) Object.assign(input, { start_image_url: image, duration: String(len), generate_audio: false });
  else if (model.startsWith("minimax/")) Object.assign(input, { image_url: image, duration: len, resolution: "768P" });
  else if (model.startsWith("bytedance/seedance")) Object.assign(input, { image_url: image, duration: String(len), resolution: "720p", generate_audio: false });
  else if (model.startsWith("alibaba/wan")) Object.assign(input, { start_image_url: image, duration: len, resolution: "720p", audio: false });
  else if (model.startsWith("google/gemini-omni")) Object.assign(input, { image_url: image, duration: len, resolution: "720p", aspect_ratio: "9:16" });
  else if (model.includes("veo3")) Object.assign(input, { image_url: image, duration: `${len}s`, resolution: "720p", aspect_ratio: "9:16", generate_audio: false });
  else Object.assign(input, { image_url: image, duration: len });
  const auth = { authorization: `Key ${need("fal")}` };
  const sub = await json<{ request_id: string; status_url: string; response_url: string }>(
    "fal.ai",
    await fetch(`https://queue.fal.run/${model}`, { method: "POST", headers: { ...auth, "content-type": "application/json" }, body: JSON.stringify(input) }),
  );
  await poll("fal.ai shot", async () => {
    const st = await json<{ status: string; error?: string }>("fal.ai", await fetch(sub.status_url, { headers: auth }));
    if (st.error) return { done: false, failed: st.error };
    return { done: st.status === "COMPLETED" };
  });
  const out = await json<{ video?: { url?: string }; error?: string; detail?: unknown }>("fal.ai", await fetch(sub.response_url, { headers: auth }));
  if (!out.video?.url) throw new Error(`fal.ai finished without a video${out.error ? `: ${out.error}` : out.detail ? `: ${JSON.stringify(out.detail).slice(0, 300)}` : ""}.`);
  return download(out.video.url, stem, ".mp4");
}

// Gemini Omni Flash answers in one long request, with the video inline.
async function veo(model: string, prompt: string, frame: string, stem: string) {
  const k = geminiKey() ?? need("gemini");
  const body = await json<{ status?: string; steps?: { type?: string; content?: { type?: string; data?: string; uri?: string; mime_type?: string }[] }[]; error?: { message?: string } }>(
    "Google",
    await fetch("https://generativelanguage.googleapis.com/v1beta/interactions", {
      method: "POST",
      headers: { "x-goog-api-key": k, "content-type": "application/json" },
      body: JSON.stringify({
        model,
        input: [
          { type: "image", mime_type: "image/jpeg", data: readFileSync(await jpeg(frame)).toString("base64") },
          { type: "text", text: prompt },
        ],
        generation_config: { video_config: { task: "image_to_video" } },
        response_format: { type: "video", aspect_ratio: "9:16", resolution: "720p", delivery: "inline" },
      }),
      signal: AbortSignal.timeout(20 * 60_000),
    }),
  );
  const video = body.steps?.flatMap((s) => s.content ?? []).find((c) => c.type === "video");
  if (video?.data) {
    writeFileSync(stem + ".mp4", Buffer.from(video.data, "base64"));
    return stem + ".mp4";
  }
  if (video?.uri) return download(video.uri, stem, ".mp4", { "x-goog-api-key": k });
  throw new Error(`Google made no video (${body.status ?? "no status"}${body.error?.message ? `: ${body.error.message}` : ""}).`);
}

async function runway(model: string, prompt: string, frame: string, len: number, stem: string) {
  const headers = { authorization: `Bearer ${need("runway")}`, "X-Runway-Version": "2024-11-06", "content-type": "application/json" };
  // Each model takes its own frame sizes; these are its portrait ones.
  const ratio = model.startsWith("kling") || model.startsWith("veo") ? (model.startsWith("veo") ? "720:1280" : "1080:1920") : "720:1280";
  const body: Record<string, unknown> = { model, promptText: prompt.slice(0, 1000), promptImage: await jpegUri(frame), ratio, duration: len };
  if (/^(veo|kling|seedance|wan)/.test(model)) body.audio = false;
  const task = await json<{ id: string }>("Runway", await fetch("https://api.dev.runwayml.com/v1/image_to_video", { method: "POST", headers, body: JSON.stringify(body) }));
  const url = await poll<string>("Runway shot", async () => {
    const t = await json<{ status: string; output?: string[]; failure?: string; failureCode?: string }>("Runway", await fetch(`https://api.dev.runwayml.com/v1/tasks/${task.id}`, { headers }));
    if (t.status === "FAILED" || t.status === "CANCELLED") return { done: false, failed: t.failure ?? t.failureCode ?? t.status };
    return { done: t.status === "SUCCEEDED", value: t.output?.[0] };
  }, 6000);
  return download(url, stem, ".mp4");
}

// Kling's new API key works on every model; the older access/secret pair signs a short-lived token for the older routes.
function klingAuth(): { header: string; legacy: boolean } {
  const apiKey = key("kling");
  if (apiKey) return { header: `Bearer ${apiKey}`, legacy: false };
  const ak = key("kling_access"), sk = key("kling_secret");
  if (!ak || !sk) need("kling");
  const enc = (o: object) => Buffer.from(JSON.stringify(o)).toString("base64url");
  const now = Math.floor(Date.now() / 1000);
  const head = `${enc({ alg: "HS256", typ: "JWT" })}.${enc({ iss: ak, exp: now + 1800, nbf: now - 5 })}`;
  return { header: `Bearer ${head}.${createHmac("sha256", sk!).update(head).digest("base64url")}`, legacy: true };
}

async function kling(model: string, prompt: string, frame: string, len: number, stem: string) {
  const base = "https://api-singapore.klingai.com";
  const image = readFileSync(await jpeg(frame)).toString("base64");
  const auth = klingAuth();
  const headers = () => ({ authorization: klingAuth().header, "content-type": "application/json" });
  if (auth.legacy) {
    const made = await json<{ code: number; message?: string; data?: { task_id: string } }>(
      "Kling",
      await fetch(`${base}/v1/videos/image2video`, {
        method: "POST",
        headers: headers(),
        body: JSON.stringify({ model_name: model === "kling-4.0" ? "kling-v4" : "kling-v3", mode: "std", prompt: prompt.slice(0, 2500), image, duration: String(len) }),
      }),
    );
    if (made.code !== 0 || !made.data) throw new Error(`Kling refused the shot: ${made.message ?? made.code}`);
    const url = await poll<string>("Kling shot", async () => {
      const t = await json<{ code: number; data?: { task_status: string; task_status_msg?: string; task_result?: { videos?: { url: string }[] } } }>("Kling", await fetch(`${base}/v1/videos/image2video/${made.data!.task_id}`, { headers: headers() }));
      if (t.data?.task_status === "failed") return { done: false, failed: t.data.task_status_msg ?? "failed" };
      return { done: t.data?.task_status === "succeed", value: t.data?.task_result?.videos?.[0]?.url };
    }, 8000);
    return download(url, stem, ".mp4");
  }
  const made = await json<{ code: number; message?: string; data?: { id: string } }>(
    "Kling",
    await fetch(`${base}/image-to-video/${model}`, {
      method: "POST",
      headers: headers(),
      body: JSON.stringify({ contents: [{ type: "prompt", text: prompt.slice(0, 3000) }, { type: "first_frame", url: image }], settings: { duration: len, resolution: "720p", ...(model === "kling-3.0" ? { audio: "off" } : {}) } }),
    }),
  );
  if (made.code !== 0 || !made.data) throw new Error(`Kling refused the shot: ${made.message ?? made.code}`);
  const url = await poll<string>("Kling shot", async () => {
    const t = await json<{ code: number; data?: { status: string; message?: string; outputs?: { type: string; url: string }[] }[] }>("Kling", await fetch(`${base}/tasks?task_ids=${made.data!.id}`, { headers: headers() }));
    const task = t.data?.[0];
    if (task?.status === "failed") return { done: false, failed: task.message || "failed" };
    return { done: task?.status === "succeeded", value: task?.outputs?.find((o) => o.type === "video")?.url };
  }, 8000);
  return download(url, stem, ".mp4");
}

async function higgsfield(model: string, prompt: string, frame: string, len: number, stem: string) {
  const auth = { authorization: `Key ${need("higgsfield_key")}:${need("higgsfield_secret")}` };
  // Higgsfield needs a real address for the frame, so it goes up to Higgsfield's own storage first.
  const up = await json<{ upload_url: string; public_url: string; upload_headers?: Record<string, string> }>(
    "Higgsfield",
    await fetch("https://api.higgsfield.ai/files/generate-upload-url", { method: "POST", headers: { ...auth, "content-type": "application/json" }, body: JSON.stringify({ content_type: "image/jpeg" }) }),
  );
  const put = await fetch(up.upload_url, { method: "PUT", headers: { "content-type": "image/jpeg", ...(up.upload_headers ?? {}) }, body: readFileSync(await jpeg(frame)) });
  if (!put.ok) throw new Error(`Couldn't upload the frame to Higgsfield (${put.status}).`);
  const input: Record<string, unknown> = model.startsWith("kling")
    ? { image_url: up.public_url, prompt, duration: len, sound: "off" }
    : { image_url: up.public_url, prompt, duration: len, resolution: "720p", generate_audio: false };
  const sub = await json<{ request_id: string; status_url?: string }>(
    "Higgsfield",
    await fetch(`https://api.higgsfield.ai/${model}`, { method: "POST", headers: { ...auth, "content-type": "application/json" }, body: JSON.stringify(input) }),
  );
  const statusUrl = sub.status_url ?? `https://api.higgsfield.ai/requests/${sub.request_id}/status`;
  const url = await poll<string>("Higgsfield shot", async () => {
    const st = await json<{ status: string; video?: { url?: string }; error?: string }>("Higgsfield", await fetch(statusUrl, { headers: auth }));
    if (["failed", "nsfw", "canceled"].includes(st.status)) return { done: false, failed: st.error ?? (st.status === "nsfw" ? "Higgsfield's content filter stopped this shot (not charged)" : st.status) };
    return { done: st.status === "completed", value: st.video?.url };
  }, 6000);
  return download(url, stem, ".mp4");
}
