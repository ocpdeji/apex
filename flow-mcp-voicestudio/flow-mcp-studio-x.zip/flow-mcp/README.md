# flow-mcp

Drive **Google Flow** (flow.google.com) from Claude, Codex or any other MCP app, or from a local control
panel, using Flow's own credits (free with any Google account: 50 a day), not the pay-per-use video API.

It is a small program that runs on your own machine. It opens its own Chrome window, signs in
as you, and clicks Flow's real buttons. There is no browser extension, no hosted service and no
account to create.

```
Claude / Codex ──stdio──> flow-mcp ──Chrome DevTools Protocol──> Chrome (its own profile) ──> Flow
```

**MCP** = Model Context Protocol, the standard that lets Claude use outside tools.
New here? [GETTING-STARTED.md](GETTING-STARTED.md) takes you from nothing to your first video, step by step, and
[OVERVIEW.md](OVERVIEW.md) explains what it does in plain English, with no code names.

---

## What you need

| | |
|---|---|
| **macOS or Windows 10/11** | Developed and tested on macOS. Windows is supported (Chrome, the computer's own voices, the Recycle Bin and the panel launcher all have Windows versions), but it hasn't been run on a real PC yet, so please report anything that breaks |
| **Node.js 22 or newer** | `node --version` |
| **Google Chrome** | Any recent version |
| **A Google account** | Free. Flow gives every account 50 credits a day; a paid Google AI plan adds more and unlocks 1080p downloads. Developed on a Pro plan |
| **FFmpeg** *(optional)* | Mac: `brew install ffmpeg` · Windows: `winget install Gyan.FFmpeg`. Needed only to join clips, mix music or record narration |
| **A Google AI Studio key** *(optional, free)* | Only for the Google narration voices. See below |
| **VoiceStudio** *(optional, free)* | The premium narration engine: your own cloned or designed voices in 646 languages. See below |
| **whisper.cpp** *(optional, free)* | Only for captions: it hears the words, on your computer. Mac: `brew install whisper-cpp` · Windows: `whisper-cli.exe` from [the whisper.cpp releases](https://github.com/ggml-org/whisper.cpp/releases), on your PATH. The speech model it needs downloads by itself the first time you caption a video: 148 MB for English, 574 MB for any other language |

A display must stay awake: the Chrome window is really being driven, so the machine cannot be
headless or asleep mid-run.

---

## Install

```bash
git clone https://github.com/GTAI-1/flow-mcp.git
cd flow-mcp
npm install
npm run build
```

> **Mac: do not put this folder in `~/Desktop`, `~/Documents` or `~/Downloads`.** macOS protects those
> folders, and apps that launch the server from there can be refused permission to read its own
> files (`EPERM: operation not permitted`). `~/flow-mcp` or anywhere in your home folder is fine.
>
> **Windows: keep it out of folders OneDrive syncs** (often Desktop and Documents), where files can be held
> online-only. `C:\Users\<you>\flow-mcp` is fine.

Then sign in, once:

```bash
npm run login
```

That opens the dedicated Chrome window. Sign into Google by hand, open (or create) a Flow project,
and leave the window open. The program never types your password; it only uses the session you
created. That Chrome profile lives in `~/.flow-mcp/chrome-profile` and is separate from your
everyday browser.

---

## Connect it to Claude, Codex or Antigravity

**Claude Code**

```bash
claude mcp add --scope user flow -- node /absolute/path/to/flow-mcp/dist/index.js
```

`--scope user` makes it available in every folder; the default (`local`) only works in the folder you ran it from.

**Claude Desktop**: add to `claude_desktop_config.json` (Mac: `~/Library/Application Support/Claude/`, Windows:
`%APPDATA%\Claude\`). On Windows, write the path with doubled backslashes, like
`"C:\\Users\\you\\flow-mcp\\dist\\index.js"`:

```json
{ "mcpServers": { "flow": { "command": "node", "args": ["/absolute/path/to/flow-mcp/dist/index.js"] } } }
```

**Codex**: add to `~/.codex/config.toml` (on Windows, `%USERPROFILE%\.codex\config.toml`):

```toml
[mcp_servers.flow]
command = "node"
args = ["/absolute/path/to/flow-mcp/dist/index.js"]
```

Or run `codex mcp add flow -- node /absolute/path/to/flow-mcp/dist/index.js`. No timeout setting is needed:
Codex, like most MCP apps, gives up on a tool call after 60 seconds, so any call that runs longer than about
45 seconds (creating a character, a 1080p download) answers with a task id instead and keeps working, and
`flow_wait` collects the result.

**Antigravity** (Google's coding app): add a `flow` entry to `mcp_config.json`. On a Mac it lives in
`~/.gemini/antigravity/`; you can also open it from the agent panel's **…** menu → **Manage MCP Servers** →
**View raw config**. Keep any servers already listed and add this one beside them:

```json
{ "mcpServers": { "flow": { "command": "node", "args": ["/absolute/path/to/flow-mcp/dist/index.js"] } } }
```

**Other MCP apps** (Cursor, VS Code and others) take the same command and arguments in their own MCP
settings. ChatGPT in the browser or the ChatGPT app can't use it: its connectors only reach servers on
the internet, and this tool has to run on your own computer to drive your Chrome window.

Developed and tested with Claude. Codex and Antigravity speak the same protocol, so they should work the
same way, but neither has been tried yet, so please report how it goes. Running two of them at once is safe:
the first one started drives Flow, and the others pass their requests to it.

Restart the app, then ask it: *"check my Flow session"*. You should get your plan and credit balance
back. Everything after that is plain English; you never type tool names.

---

## Your first film

Nothing below costs a credit until step 4, and the assistant asks before spending.

1. **Check the session.** *"Check my Flow session."* This confirms sign-in, plan and credits.
2. **Make a character.** *"Create a character called Pip, a small lamplighter in a flat cartoon style."*
   Flow draws the portrait. Free.
3. **Draw the key frames.** *"Draw three stills with Pip: a dark rooftop, him lighting a lamp, the
   whole hillside glowing. Match each one to the last."* Free: stills cost nothing, so get the look
   right here before spending.
4. **Shoot it.** *"Turn those into three 10-second shots, each starting where the last one ended,
   720p, no more than 15 credits each."* This spends credits. The price is read from Flow's own
   quote first and the scene is skipped if it is over your cap.
5. **Narrate it.** *"Record this line with a warm documentary voice."* Free, any length.
6. **Cut it.** *"Join the three shots under the narration, don't freeze the last frame."*
   The finished file lands in `~/flow-mcp-out/<project>/`.

---

## The control panel

The same features, without an AI assistant in the loop:

```bash
npm run studio     # then open http://127.0.0.1:8787
```

or double-click **Flow Studio.command** (Mac) or **Flow Studio.cmd** (Windows).

Eight tabs, in the order you would use them:

- **Cast**: reusable characters. Create them, edit them in place, or build one from a picture.
- **Frames**: free stills, with *match previous frame* to keep a set on-model.
- **Shots**: paid clips, with first/last frames, chaining, a live credit estimate, and a card that
  continues a finished clip from its own last frame.
- **Voice**: free narration in Google's voices or your computer's own. Your saved narrations are listed
  here to play or delete, and there's a field for your Google AI Studio key (checked with Google, stored
  only on your computer; never paste it into a chat).
- **Restyle**: change a clip you already have.
- **Cut**: join any videos into one film, in the order you pick. Upload one, or choose from films you've
  already made. Add a narration (from your saved ones or an upload) and music, and turn the clips' own
  sound down so the narration sits on top.
- **Captions**: put the spoken words on screen, the way short-form videos do, on wide or vertical videos.
  Pick a video and the language spoken in it (about 100 languages, or Detect automatically), choose a
  style (Bold pop, Highlight, Word by word, Clean, Boxed), where it sits (bottom,
  middle, top, an exact height, or tap the preview), its size (a slider), its letters (normal, CAPS or lowercase) and
  highlight colour, and see it on a real frame of your video before anything is made. Fix any misheard
  word in the text box and it keeps its timing; press Enter to start a new caption. Saves `<name>-captions.mp4` plus an `.srt` for YouTube.
  Everything happens on your computer; nothing is uploaded.
- **Library**: everything in your Flow project. Download it again for free (a scene comes down as one
  finished film, not loose clips), or move it to Flow's Trash.

A progress monitor and a gallery of your saved work sit alongside. The gallery shows stills or clips
on the tabs that use them. On a wide screen, each side scrolls on its own. Two kinds of delete, clearly
labelled: **Move to the Mac's Trash / Recycle Bin** removes a file from your computer; **Move to
Flow's Trash** removes it from your Flow project only. Both can be undone.

The panel ships with the repo but is not started for you: run `npm run studio` when you want it.
Opening `studio/index.html` as a plain file does nothing; the page needs the server behind it, and
says so in red if you try.

Claude's own process serves the same panel while it runs. Whichever process starts first owns the
Chrome tab and the job queue; the other talks to it over a local API, so Claude and the panel always
agree on what is running. That API listens on 127.0.0.1 only and needs a per-run token
(`~/.flow-mcp/token`).

---

## Tools

| Tool | Purpose |
|---|---|
| `flow_status` | Session state (signed in, project open, plan, credits left), queue, pacing, prompt playbook |
| `flow_generate` | Queue scenes: prompt, image or video, model, aspect, duration, resolution, variants, first/last frame, reference images, `max_credits` cap |
| `flow_wait` | Wait for jobs, or for the task id of a slow call; returns file paths and results. Answers within about 40 s, so call again until `finished` is true |
| `flow_cancel` | Cancel a job that has not started |
| `flow_retry` | Re-queue failed jobs with the same settings and file names (a failed tile is first retried inside Flow with its own free Retry button: `retries`, default 1) |
| `flow_assets` | List images and videos already in the Flow project (usable as `asset:<title>`) |
| `flow_download` | Download existing project media without regenerating. Free, including the 1080p / 2K upscale. A scene comes down as one stitched film |
| `flow_trash` | Move an image, video or scene in the Flow project to Flow's Trash, where it can be restored. Exact title only; refuses if two items share it; never deletes permanently |
| `flow_agent_images` | Fast image batch: hands up to 50 scenes to Flow's own Agent mode, rendered in parallel (20 images in ~204 s), 0 credits. Each image is matched back to its scene by its stored prompt, so file numbers are right in any finish order. Scenes the agent drops are re-asked of it (up to 2 rounds), then re-run one by one. `references` attaches characters, places and objects once in the agent's composer (like its + button), and `scene_references` says which scenes use which, so a whole story stays on-model; scenes made one by one keep their references |
| `flow_edit` | Video-to-video edit of a clip already in the project (relight, weather, remove objects). Flow shows no quote first; about 20 credits for a 4 s clip |
| `flow_continue` | Start a clip from the last frame of an existing one **with a character or your avatar still attached**. The composer allows a start frame or attached characters, never both, so this drives Flow's agent mode, which does both. No quote beforehand |
| `flow_character` | Create a reusable character from a description (Flow draws the portrait) or an image, with a personality and a stock voice; use it as `asset:<name>` |
| `flow_character_edit` | Restyle an existing character in place (free) and save the new portrait; name, personality and voice are kept, so every scene referencing it updates. Pass `look` with the updated description; with only a name it re-saves the current portrait |
| `flow_characters` | List the project's characters |
| `flow_techniques` | 39 film-technique prompt presets (camera moves, product shots, transitions, image commands); pass an id as a scene's `technique` |
| `flow_narrate` | Free narration audio: `gemini` (Google AI Studio text-to-speech, with the same voices Flow has, plus a `style` note), `mac` (a voice installed on this computer, no key needed) or `voicestudio` (premium: your own cloned or designed voices, 646 languages, personality, speed, quality, finishing effect, seed, exact length, whole scripts in one take) |
| `flow_voices` | Narrator voices available, whether a Google key is set up, and VoiceStudio's status, voices, engines, personalities and effects |
| `flow_drama_new` / `flow_drama_run` / `flow_drama_status` | Start a micro-drama from a title and idea, make it stage by stage (asking before spending), and follow it |
| `flow_drama_script` / `flow_drama_redo` / `flow_drama_settings` / `flow_drama_providers` | Write or edit the script in chat, redo one item, switch generators, and see which generators and keys are ready |
| `flow_voice_clone` | Make a VoiceStudio voice from a 5-30 second recording (only with the speaker's permission) |
| `flow_voice_design` | Make a VoiceStudio voice from a description (gender, age, pitch, whisper, accent); `preview_only` checks the description first |
| `flow_captions` | Burn spoken-word captions into any video, landscape or vertical, in one of five styles, at any height and size, in normal, capital or lowercase letters, in about 100 languages; returns the transcript so a misheard word can be fixed and the call repeated (local whisper.cpp, Chrome and FFmpeg, no credits) |
| `flow_transcribe` | Hear the words in any video or audio on your computer, with each word's start and end time (local whisper.cpp, free) |
| `flow_assemble` | Join clips into one MP4 (a project's clips, or any you list, in order) with optional music and voiceover, and separate volume for the clips' own sound. A voiceover can also be built line by line (`voice_lines`), each line cut from a take and placed at its own moment, for narration timed to on-screen titles (local FFmpeg, no credits) |

**Continuity between shots:** `chain_previous` (this clip starts on the last frame of the previous
one), `first_frame` + `last_frame` (animate between two stills you chose), `reference_images` (keep a
character or product consistent). Flow's *composer* takes either frames or references, never both, so
when you need a start frame **and** a character locked together, use `flow_continue`, which goes through
Flow's agent mode and does both.

Output lands in `~/flow-mcp-out/<project>/scene-NN.ext`.

### Narration with Google's voices (optional)

`flow_narrate` with `engine: "mac"` uses your computer's own voices and works out of the box: macOS voices on a
Mac, the built-in speech voices on Windows. For Google's voices (the same ones Flow offers), get a free key from
[Google AI Studio](https://aistudio.google.com/apikey) and paste it into **Flow Studio → Voice → Google AI Studio
key → Save key**. It's checked with Google before it's saved, and stored only on your computer. Or set
`GEMINI_API_KEY`. Either way, never paste the key into a chat; it would end up in the conversation history.

### Drama Studio: a whole video from a title and an idea

**Flow Studio → Drama ✦** (or ask Claude: *"make a 60-second micro-drama called The CEO's Secret Twin about…"*) runs
the whole pipeline and stops for your OK before anything that costs money.

**Production types** (set with `type` or in the panel): micro_drama, documentary, bible, ugc, youtube_long,
youtube_short, tiktok, reels, product_ad, explainer, animated, trailer, podcast, music_montage, custom. The type
decides the script shape, pacing, average shot length and default caption style.

**Platform presets** (set with `platform` or in the panel): tiktok, youtube_shorts, youtube, reels, instagram_feed,
facebook, facebook_reels, linkedin, vertical, landscape, square, portrait. The platform picks the aspect ratio and
the recommended length range; `aspect` overrides it.

**Spending caps** (set with `budget_usd` and `budget_credits`): a run stops with an explanation when it would spend
more than you set, so a long video can't quietly run up a big bill.

**Pause and resume**: `flow_drama_cancel` asks the pipeline to stop after the current item. Already-made work is kept.
Call `flow_drama_run` again to pick up.

**Import an existing video**: `flow_drama_import` copies a video or audio file into a new drama, transcribes it with
whisper.cpp (same engine used for captions), breaks it into shots, and builds a drama script around it. The source
file is never changed. You can then edit the script and re-render parts with any of the generators.

**Pipeline stages**:

1. **Write**: script, characters, shots, dialogue, hook and cliffhanger
2. **Cast**: a reference portrait of every character
3. **Voices**: every line spoken, one distinct voice per character
4. **Frames**: a still for each shot, with the characters kept on-model
5. **Shots**: each frame animated, made long enough for its lines
6. **Sound**: optional sound effects and music
7. **QA**: deterministic checks (missing files, dialogue too long for its shot, unknown characters, unexpected runtime); warnings only, nothing is auto-fixed
8. **Cut**: the finished video with captions, in the chosen aspect ratio

You pick the generator for each step and can switch any time. Anything already made is kept, and any single portrait,
line, frame or shot can be redone with a new prompt.

| Step | Choices |
|---|---|
| Writer | Claude (Anthropic key), OpenAI, Gemini, or Claude in chat with no key |
| Images | Flow (free), Gemini (Nano Banana), OpenAI (GPT Image), fal.ai (Nano Banana, FLUX 3), OpenRouter |
| Video | Flow (your credits), fal.ai (Kling 4.0/3.0, Hailuo H3, Seedance 2.5/2.0, Wan 3.0, Gemini Omni), Google Gemini Omni Flash, Runway (Gen-4.5 and partner models), Kling, Higgsfield. OpenArt has no public API, so it can't be connected |
| Voices | VoiceStudio (free, designs a voice per character), Google (free), this computer's voices, ElevenLabs, OpenAI |
| Music and effects | ElevenLabs, or your own music file |

Keys go in **Drama → Keys** and are saved only on your computer (`~/.flow-mcp/keys.json`). Claude can see which keys
are saved, never the keys themselves. Every episode lives in `~/flow-mcp-out/Dramas/<title>/`, with the finished
`<title>-episode.mp4` (plus a captioned copy) next to its cast, voices, frames and shots.

### Many Google accounts: switch between them in one click

flow-mcp uses one dedicated Chrome window for Google Flow, so one Google account is signed in at a time. If you have
several accounts with their own Flow credits, create a slot for each one. Switching between slots takes a click, with
no cookie copying or risky session tricks: each slot is its own Chrome profile under `~/.flow-mcp/accounts/<name>`,
and you sign in once per slot.

Create a slot and switch to it from the panel's **Flow account:** dropdown at the top (the **+** button adds a new
one), or from Claude:

```
flow_account_create { "name": "personal" }
flow_account_switch { "name": "personal" }
```

Then run `npm run login` once from PowerShell to sign in with the Google account you want in that slot. From then on,
switching between accounts in the panel instantly swaps which Chrome profile flow-mcp uses, closes the old window and
opens a new one with the chosen account's Flow credits.

Tools: `flow_account_list`, `flow_account_switch`, `flow_account_create`, `flow_account_rename`, `flow_account_remove`.
Your old sign-in is kept — it moves to the "default" slot the first time an account tool runs.

### Premium narration with VoiceStudio (optional)

[VoiceStudio](https://github.com/debpalash/VoiceStudio) is a free, open-source voice app that runs on your own
computer. With it open, `flow_narrate` with `engine: "voicestudio"` (or **Flow Studio → Voice → VoiceStudio ✦**) speaks
in your own cloned or designed voices, in 646 languages, with personality presets, speed (0.5-2x), quality
(draft, balanced, studio), a finishing effect (broadcast, cinematic, podcast, warm, bright, raw), a fixed seed for a
repeatable read, an exact length to fit a shot, and whole scripts of up to 20,000 characters in one take. It also lets you
pick any other speech engine you've installed in VoiceStudio, and that engine's built-in voices.

1. Install it. Windows, in PowerShell: `irm https://raw.githubusercontent.com/debpalash/VoiceStudio/main/scripts/install.ps1 | iex`. Mac, in Terminal:
   `curl -fsSL https://voicestudio.sh/install | sh`. Or download it from its
   [releases page](https://github.com/debpalash/VoiceStudio/releases/latest).
2. Open it once and let it finish its first-run setup (it downloads its voice model, about 2.3 GB). It runs on any
   computer, faster with a graphics card.
3. Keep VoiceStudio open while you use Flow. **Flow Studio → Voice → VoiceStudio ✦** shows a green light when it's
   ready, and lets you clone a voice from a recording or design one from a description.

Flow talks to VoiceStudio at `http://127.0.0.1:3900`. Set `VOICESTUDIO_URL` to use one elsewhere (and
`OMNIVOICE_API_KEY` if that one needs a key). Only clone a voice that is yours or that you have permission to use.

---

## Behaviour and settings

- One generation at a time, with a random 25–70 second pause between them. The page carries an
  invisible reCAPTCHA; this drives the real interface at human pace and does nothing to evade it.
- Before each generation the server reads Flow's own credit quote and skips the scene if it exceeds
  `max_credits` (default 25).
- Any Google account language works. The server finds Flow's buttons by their English names, so its
  Chrome window always shows Flow in English (it adds `?hl=en` to the address). Your account's own
  language setting is never changed, and prompts can be written in any language.
- Environment variables: `GEMINI_API_KEY`, `VOICESTUDIO_URL` (http://127.0.0.1:3900), `OMNIVOICE_API_KEY`, `FLOW_MCP_PORT` (8787), `FLOW_MCP_OUTPUT`,
  `FLOW_MCP_HOME`, `FLOW_MCP_CDP_PORT` (9333), `FLOW_MCP_CHROME`, `FLOW_MCP_PAUSE_MIN_S`,
  `FLOW_MCP_PAUSE_MAX_S`.

## If something goes wrong

| Symptom | Cause |
|---|---|
| Mac: the server will not start, `EPERM: operation not permitted` | The folder is in a macOS-protected location. Move it out of `~/Desktop`, `~/Documents` or `~/Downloads` and update the path in your Claude config |
| *"Not signed in"* or *"no project open"* | Run `npm run login`, sign in, open a Flow project, leave the window open |
| A clip generated but no file arrived | The media is still in Flow. `flow_download` pulls it back for nothing. Never re-generate and pay twice |
| Everything times out | The Chrome window was closed, or the machine slept. Reopen it with `npm run login` |
| *"VoiceStudio isn't running"* | Open the VoiceStudio app and wait for it to finish starting, then try again (Flow Studio's Voice tab has a Refresh button) |

---

## Updating

Tell your assistant: *"Update Flow MCP: in my flow-mcp folder, run git pull, then npm install, then npm run
build."* Then fully quit and reopen your assistant app so it loads the new version.

---

## Licence and risk

This automates Flow's web interface. It can break whenever Google changes that interface, and
automated use may be against Google's terms of service. Use it on your own account, at your own
risk.
