import { existsSync, mkdirSync, readFileSync, readdirSync, renameSync, rmSync, writeFileSync } from "node:fs";
import { basename, join } from "node:path";
import { HOME_DIR } from "./chrome.js";

// Named Google-account slots. Each one is its own Chrome profile folder, so a sign-in in one account doesn't disturb
// the others. The current slot is written to accounts/active.txt. The first time any of this runs, the old flat
// `chrome-profile` folder (from before accounts existed) is moved to accounts/default/chrome-profile and that account
// becomes active, so no one has to sign in again.

export const ACCOUNTS_DIR = join(HOME_DIR, "accounts");
const ACTIVE_FILE = join(ACCOUNTS_DIR, "active.txt");
const PID_FILE = join(HOME_DIR, "chrome.pid");

const safe = (name: string) => {
  const clean = name.trim().toLowerCase().replace(/[^a-z0-9._-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 48);
  if (!clean) throw new Error("Account name must have letters, numbers, dots, underscores or hyphens.");
  return clean;
};

function migrate(): void {
  mkdirSync(ACCOUNTS_DIR, { recursive: true });
  const legacy = join(HOME_DIR, "chrome-profile");
  const defaultSlot = join(ACCOUNTS_DIR, "default");
  // A previous flat profile moves to the "default" account the first time.
  if (existsSync(legacy) && !existsSync(defaultSlot)) {
    mkdirSync(defaultSlot, { recursive: true });
    renameSync(legacy, join(defaultSlot, "chrome-profile"));
  }
  if (!readdirSync(ACCOUNTS_DIR).some((n) => n !== "active.txt" && !n.startsWith("."))) {
    mkdirSync(join(defaultSlot, "chrome-profile"), { recursive: true });
  }
  if (!existsSync(ACTIVE_FILE)) {
    const first = readdirSync(ACCOUNTS_DIR).find((n) => n !== "active.txt" && !n.startsWith("."));
    writeFileSync(ACTIVE_FILE, first ?? "default", { mode: 0o600 });
  }
}

export function activeAccount(): string {
  migrate();
  const name = readFileSync(ACTIVE_FILE, "utf8").trim();
  if (!name) return "default";
  // A stale name after a rename or delete falls back to any existing slot.
  if (!existsSync(join(ACCOUNTS_DIR, name))) {
    const fallback = readdirSync(ACCOUNTS_DIR).find((n) => n !== "active.txt" && !n.startsWith(".")) ?? "default";
    writeFileSync(ACTIVE_FILE, fallback, { mode: 0o600 });
    return fallback;
  }
  return name;
}

export function activeProfileDir(): string {
  const dir = join(ACCOUNTS_DIR, activeAccount(), "chrome-profile");
  mkdirSync(dir, { recursive: true });
  return dir;
}

export function listAccounts(): { name: string; active: boolean; signed_in: boolean }[] {
  migrate();
  const active = activeAccount();
  return readdirSync(ACCOUNTS_DIR, { withFileTypes: true })
    .filter((d) => d.isDirectory() && !d.name.startsWith("."))
    .map((d) => {
      const profile = join(ACCOUNTS_DIR, d.name, "chrome-profile");
      // Chrome writes "Default" and "First Run" inside the profile folder once sign-in has happened.
      const signed_in = existsSync(join(profile, "Default")) || existsSync(join(profile, "First Run"));
      return { name: d.name, active: d.name === active, signed_in };
    })
    .sort((a, b) => a.name.localeCompare(b.name));
}

export function createAccount(name: string): { name: string; dir: string; new: boolean } {
  const slug = safe(name);
  const dir = join(ACCOUNTS_DIR, slug, "chrome-profile");
  const made = !existsSync(dir);
  mkdirSync(dir, { recursive: true });
  return { name: slug, dir, new: made };
}

export function renameAccount(from: string, to: string): { name: string } {
  const a = safe(from), b = safe(to);
  if (a === b) return { name: a };
  const src = join(ACCOUNTS_DIR, a), dst = join(ACCOUNTS_DIR, b);
  if (!existsSync(src)) throw new Error(`No account called "${from}".`);
  if (existsSync(dst)) throw new Error(`An account called "${to}" already exists.`);
  renameSync(src, dst);
  if (activeAccount() === a) writeFileSync(ACTIVE_FILE, b, { mode: 0o600 });
  return { name: b };
}

export function removeAccount(name: string): { removed: string } {
  const slug = safe(name);
  const dir = join(ACCOUNTS_DIR, slug);
  if (!existsSync(dir)) throw new Error(`No account called "${name}".`);
  if (listAccounts().length === 1) throw new Error("At least one account must remain. Create another one first, then remove this one.");
  if (activeAccount() === slug) {
    const other = listAccounts().find((a) => a.name !== slug);
    if (other) writeFileSync(ACTIVE_FILE, other.name, { mode: 0o600 });
  }
  rmSync(dir, { recursive: true, force: true });
  return { removed: slug };
}

// Switching closes the running Chrome and marks the new account active. The next Flow call opens a fresh Chrome on it.
export async function switchAccount(name: string): Promise<{ active: string; chrome_closed: boolean }> {
  const slug = safe(name);
  if (!existsSync(join(ACCOUNTS_DIR, slug))) throw new Error(`No account called "${name}". flow_account_list shows them all.`);
  const closed = await closeChrome();
  writeFileSync(ACTIVE_FILE, slug, { mode: 0o600 });
  return { active: slug, chrome_closed: closed };
}

// Records the PID of the Chrome flow-mcp just started, so we can bring it down ourselves when the account changes.
export function noteChromePid(pid: number): void {
  mkdirSync(HOME_DIR, { recursive: true });
  writeFileSync(PID_FILE, String(pid), { mode: 0o600 });
}

async function closeChrome(): Promise<boolean> {
  if (!existsSync(PID_FILE)) return false;
  const pid = Number(readFileSync(PID_FILE, "utf8").trim());
  if (!pid) return false;
  try {
    process.kill(pid, "SIGTERM");
  } catch {
    // Already gone.
    rmSync(PID_FILE, { force: true });
    return false;
  }
  // Give Chrome up to 6 seconds to exit, then a hard kill.
  for (let i = 0; i < 12; i++) {
    await new Promise((r) => setTimeout(r, 500));
    try {
      process.kill(pid, 0);
    } catch {
      rmSync(PID_FILE, { force: true });
      return true;
    }
  }
  try {
    process.kill(pid, "SIGKILL");
  } catch {}
  rmSync(PID_FILE, { force: true });
  return true;
}

// Reads the base name of a path safely, for tests.
export const _accountNameFromPath = (p: string) => basename(p);
