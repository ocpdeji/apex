// Platform presets: where the video will be posted, what aspect ratio and length it needs. The platform picks a sensible
// aspect ratio and duration range; the blueprint (micro-drama, documentary...) decides the structure. Both reach the
// pipeline, so a documentary cut for YouTube comes out 16:9 and multiple minutes while the same documentary for Shorts
// comes out 9:16 and under a minute.

export type AspectRatio = "9:16" | "16:9" | "1:1" | "4:5";

export interface Platform {
  id: string;
  label: string;
  aspect: AspectRatio;
  min_seconds: number;
  max_seconds: number;
  recommended_seconds: number;
  // Width in which to render; the vertical dimension follows the aspect ratio.
  render_width: number;
}

// Current platform limits as of October 2026. Each limit stays conservative compared with the platform's own hard cap,
// to leave room for intro and outro and keep the piece under the limit without rework.
export const PLATFORMS: Record<string, Platform> = {
  tiktok: { id: "tiktok", label: "TikTok", aspect: "9:16", min_seconds: 15, max_seconds: 180, recommended_seconds: 30, render_width: 1080 },
  youtube_shorts: { id: "youtube_shorts", label: "YouTube Shorts", aspect: "9:16", min_seconds: 15, max_seconds: 60, recommended_seconds: 45, render_width: 1080 },
  youtube: { id: "youtube", label: "YouTube", aspect: "16:9", min_seconds: 60, max_seconds: 3600, recommended_seconds: 300, render_width: 1920 },
  reels: { id: "reels", label: "Instagram Reels", aspect: "9:16", min_seconds: 15, max_seconds: 90, recommended_seconds: 30, render_width: 1080 },
  instagram_feed: { id: "instagram_feed", label: "Instagram feed", aspect: "1:1", min_seconds: 10, max_seconds: 60, recommended_seconds: 30, render_width: 1080 },
  facebook: { id: "facebook", label: "Facebook video", aspect: "16:9", min_seconds: 30, max_seconds: 900, recommended_seconds: 90, render_width: 1920 },
  facebook_reels: { id: "facebook_reels", label: "Facebook Reels", aspect: "9:16", min_seconds: 15, max_seconds: 90, recommended_seconds: 30, render_width: 1080 },
  linkedin: { id: "linkedin", label: "LinkedIn video", aspect: "16:9", min_seconds: 30, max_seconds: 600, recommended_seconds: 90, render_width: 1920 },
  vertical: { id: "vertical", label: "Any vertical", aspect: "9:16", min_seconds: 5, max_seconds: 1800, recommended_seconds: 60, render_width: 1080 },
  landscape: { id: "landscape", label: "Any landscape", aspect: "16:9", min_seconds: 5, max_seconds: 1800, recommended_seconds: 60, render_width: 1920 },
  square: { id: "square", label: "Any square", aspect: "1:1", min_seconds: 5, max_seconds: 1800, recommended_seconds: 30, render_width: 1080 },
  portrait: { id: "portrait", label: "Portrait 4:5", aspect: "4:5", min_seconds: 5, max_seconds: 1800, recommended_seconds: 30, render_width: 1080 },
};

export const platform = (id?: string): Platform => PLATFORMS[id ?? ""] ?? PLATFORMS.vertical;

export const platformSize = (p: Platform) => {
  const [w, h] = p.aspect.split(":").map(Number);
  const width = p.render_width;
  const height = Math.round((width * h) / w);
  return { width, height };
};
