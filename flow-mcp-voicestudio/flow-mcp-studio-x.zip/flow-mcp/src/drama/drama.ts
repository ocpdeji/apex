import { execFile } from "node:child_process";
import { copyFileSync, existsSync, mkdirSync, readdirSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { promisify } from "node:util";
import { assemble, voiceTrack } from "../assemble.js";
import { burnCaptions, captionedName } from "../captions.js";
import { BLUEPRINTS, blueprint, planShots, type BlueprintId } from "./blueprints.js";
import { PLATFORMS, platform, platformSize } from "./platforms.js";
import { importVideo, type Imported } from "./import.js";
import { checkDrama } from "./qa.js";
import { clean, writeScript, type Brief, type Script, type Writer } from "./script.js";
import {
  IMAGE_PROVIDERS,
  VIDEO_PROVIDERS,
  VOICE_PROVIDERS,
  estimate,
  makeImage,
  makeMusic,
  makeSound,
  makeVideo,
  pickVoices,
  speakLine,
  type ImageProvider,
  type VideoProvider,
  type VoiceChoice,
  type VoiceProvider,
} from "./providers.js";

const run = promisify(execFile);
const FFPROBE = process.env.FLOW_MCP_FFPROBE ?? "ffprobe";

// What Flow itself does for the studio. LocalCore supplies it, so Flow's own queue, pacing and credit guard still
// decide every Flow generation; the studio only waits for the result.
export interface FlowBridge {
  image(prompt: string, refs: string[], out_dir: string, stem: string): Promise<string>;
  video(prompt: string, first_frame: string, seconds: number, model: string | undefined, max_credits: number, out_dir: string, stem: string): Promise<{ file: string; credits?: number }>;
  character(name: string, look: string): Promise<{ asset: string; portrait?: string }>;
}

export const STAGES = ["write", "cast", "voices", "frames", "shots", "sound", "qa", "cut"] as const;
export type Stage = (typeof STAGES)[number];

type ItemStatus = "todo" | "running" | "done" | "failed";
interface Item {
  status: ItemStatus;
  file?: string;
  error?: string;
  cost_usd?: number;
  credits?: number;
}
export interface Line {
  scene: number;
  character: string;
  text: string;
  emotion: string;
  file?: string;
  seconds?: number;
  status: ItemStatus;
  error?: string;
}

export interface Providers {
  writer: { id: Writer; model?: string };
  image: { id: ImageProvider; model?: string };
  video: { id: VideoProvider; model?: string };
  voice: { id: VoiceProvider; model?: string };
  music: { id: "none" | "elevenlabs" | "file"; file?: string };
  sound_effects: boolean;
}

export interface Options {
  captions: boolean;
  caption_style: "bold" | "highlight" | "reveal" | "clean" | "boxed";
  max_credits: number;
  clip_volume: number;
  music_volume: number;
  // Pay cap: a run stops with an explanation when it would spend past this on money or on Flow credits.
  budget_usd?: number;
  budget_credits?: number;
  // The platform this piece is being made for. Decides aspect ratio and the recommended length range.
  platform?: string;
  // Hard override for aspect ratio when the user wants it different from the platform's.
  aspect?: "9:16" | "16:9" | "1:1" | "4:5";
}

export interface Drama {
  slug: string;
  dir: string;
  created: string;
  updated: string;
  brief: Brief;
  providers: Providers;
  options: Options;
  script?: Script;
  cast: Record<string, Item & { asset?: string; voice?: VoiceChoice }>;
  lines: Line[];
  frames: Item[];
  shots: Item[];
  sounds: Item[];
  music?: Item;
  final?: Item & { captioned?: string };
  approved_usd: number;
  spent_usd: number;
  spent_credits: number;
  running?: { stage: Stage; item?: string; since: string };
  // A run that was asked to pause finishes its current item, writes a note, and lets the pipeline exit; a resume
  // simply calls flow_drama_run again.
  pause_requested?: boolean;
  warnings: string[];
  log: string[];
}

export const slugOf = (title: string) => title.trim().replace(/[^\w.-]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 60) || "Untitled";

export class Studio {
  private live = new Map<string, Promise<void>>();

  constructor(
    private root: string,
    private flow: FlowBridge,
  ) {}

  // Shared helpers so the pipeline, the panel's own code and callers all agree on the shape of a running pipeline.
  async importFrom(a: { title: string; video: string; type?: BlueprintId; language?: string; aspect?: "9:16" | "16:9" | "1:1" | "4:5"; providers?: Partial<Providers>; options?: Partial<Options> }) {
    const slug = slugOf(a.title);
    if (existsSync(this.file(slug))) throw new Error(`A drama called "${a.title}" already exists. Open it, or use a different title.`);
    const dir = join(this.root, slug);
    const imported = await importVideo({ video: a.video, title: a.title, type: a.type, aspect: a.aspect, language: a.language, dir });
    const d = this.create({
      brief: { title: a.title, idea: `Edited from ${a.video}`, type: a.type, aspect: a.aspect, language: imported.language, seconds: Math.ceil(imported.seconds) },
      providers: { ...a.providers, writer: { id: "chat" } },
      options: a.options,
      script: imported.script,
    });
    this.note(d, `imported from ${a.video} (${imported.words} words, ${Math.round(imported.seconds)}s)`);
    return { ...this.summary(d), imported: { file: imported.copy, seconds: imported.seconds, words: imported.words } };
  }

  cancel(slug: string) {
    const d = this.load(slug);
    d.pause_requested = true;
    this.note(d, "pause requested — the pipeline will stop after the current item");
    return this.summary(d);
  }

  private file = (slug: string) => join(this.root, slug, "drama.json");

  list() {
    if (!existsSync(this.root)) return [];
    return readdirSync(this.root, { withFileTypes: true })
      .filter((d) => d.isDirectory() && existsSync(this.file(d.name)))
      .map((d) => this.summary(this.load(d.name)))
      .sort((a, b) => b.updated.localeCompare(a.updated));
  }

  load(slug: string): Drama {
    const f = this.file(slugOf(slug));
    if (!existsSync(f)) throw new Error(`There's no drama called "${slug}". flow_drama_list shows them all.`);
    const d = JSON.parse(readFileSync(f, "utf8")) as Drama;
    d.warnings = d.warnings ?? [];
    return d;
  }

  private save(d: Drama) {
    d.updated = new Date().toISOString();
    mkdirSync(d.dir, { recursive: true });
    const tmp = this.file(d.slug) + ".tmp";
    writeFileSync(tmp, JSON.stringify(d, null, 2));
    renameSync(tmp, this.file(d.slug));
  }

  private note(d: Drama, msg: string) {
    d.log = [...d.log, `${new Date().toISOString().slice(11, 19)} ${msg}`].slice(-200);
    this.save(d);
  }

  create(a: { brief: Brief; providers?: Partial<Providers>; options?: Partial<Options>; script?: Script; replace?: boolean }): Drama {
    const slug = slugOf(a.brief.title);
    if (existsSync(this.file(slug)) && !a.replace) throw new Error(`A drama called "${a.brief.title}" already exists. Open it, or pass replace: true to start over.`);
    const now = new Date().toISOString();
    const d: Drama = {
      slug,
      dir: join(this.root, slug),
      created: now,
      updated: now,
      brief: a.brief,
      providers: {
        writer: a.providers?.writer ?? { id: a.script ? "chat" : "anthropic" },
        image: a.providers?.image ?? { id: "flow" },
        video: a.providers?.video ?? { id: "flow" },
        voice: a.providers?.voice ?? { id: "gemini" },
        music: a.providers?.music ?? { id: "none" },
        sound_effects: a.providers?.sound_effects ?? false,
      },
      options: (() => { const bp = blueprint(a.brief.type); const pl = a.brief.platform ? platform(a.brief.platform) : null; return { captions: true, caption_style: bp.default_caption_style, max_credits: 25, clip_volume: 0.35, music_volume: 0.18, platform: a.brief.platform, aspect: a.brief.aspect ?? pl?.aspect ?? bp.default_aspect, ...a.options }; })(),
      cast: {},
      lines: [],
      frames: [],
      shots: [],
      sounds: [],
      approved_usd: 0,
      spent_usd: 0,
      spent_credits: 0,
      log: [],
      warnings: [],
    };
    if (a.script) this.adopt(d, clean(a.script, a.brief));
    this.save(d);
    return d;
  }

  // A new or edited script resets whatever was made from it: shots of a rewritten scene would no longer match.
  private adopt(d: Drama, s: Script, keepCast = false) {
    const old = d.cast;
    d.script = s;
    d.cast = Object.fromEntries(s.characters.map((c) => [c.name, keepCast && old[c.name] ? old[c.name] : { status: "todo" as ItemStatus }]));
    d.lines = s.scenes.flatMap((sc, i) => [
      ...sc.dialogue.map((l) => ({ scene: i, character: l.character, text: l.line, emotion: l.emotion, status: "todo" as ItemStatus })),
      ...(sc.narration ? [{ scene: i, character: "Narrator", text: sc.narration, emotion: "calm", status: "todo" as ItemStatus }] : []),
    ]);
    d.frames = s.scenes.map(() => ({ status: "todo" }));
    d.shots = s.scenes.map(() => ({ status: "todo" }));
    d.sounds = s.scenes.map(() => ({ status: "todo" }));
    d.final = undefined;
  }

  setScript(slug: string, script: Script, keepCast = true) {
    const d = this.load(slug);
    if (this.live.has(d.slug)) throw new Error("This drama is being made right now. Wait for it to finish, then edit the script.");
    this.adopt(d, clean(script, d.brief), keepCast);
    this.note(d, "script replaced");
    return this.summary(d);
  }

  configure(slug: string, a: { providers?: Partial<Providers>; options?: Partial<Options>; voices?: Record<string, VoiceChoice> }) {
    const d = this.load(slug);
    if (this.live.has(d.slug)) throw new Error("This drama is being made right now. Change settings once it has finished.");
    // Only what was actually given changes; a setting left out keeps its value.
    const given = <T extends object>(o?: T) => Object.fromEntries(Object.entries(o ?? {}).filter(([, v]) => v !== undefined)) as Partial<T>;
    d.providers = { ...d.providers, ...given(a.providers) };
    d.options = { ...d.options, ...given(a.options) };
    for (const [name, v] of Object.entries(a.voices ?? {})) {
      if (!d.cast[name]) throw new Error(`No character called "${name}".`);
      d.cast[name].voice = v;
      // A new voice means every line of that character is recorded again.
      for (const l of d.lines) if (l.character === name) l.status = "todo";
    }
    this.save(d);
    return this.summary(d);
  }

  // Marks one thing to be made again on the next run, optionally with a new prompt or line.
  redo(slug: string, a: { what: "portrait" | "line" | "frame" | "shot" | "sound" | "music" | "final"; scene?: number; character?: string; index?: number; prompt?: string; motion?: string; text?: string }) {
    const d = this.load(slug);
    if (this.live.has(d.slug)) throw new Error("This drama is being made right now. Redo things once it has finished.");
    const s = d.script;
    if (!s) throw new Error("There's no script yet.");
    const sc = a.scene !== undefined ? a.scene - 1 : -1;
    const scene = () => {
      if (sc < 0 || sc >= s.scenes.length) throw new Error(`Scene must be 1 to ${s.scenes.length}.`);
      return s.scenes[sc];
    };
    if (a.what === "portrait") {
      const c = s.characters.find((x) => x.name.toLowerCase() === (a.character ?? "").toLowerCase());
      if (!c) throw new Error(`No character called "${a.character}". Characters: ${s.characters.map((x) => x.name).join(", ")}.`);
      if (a.prompt) c.look = a.prompt;
      d.cast[c.name] = { ...d.cast[c.name], status: "todo", file: undefined, asset: undefined };
      // Their face changes, so every frame they appear in is drawn again, and those shots are made again.
      s.scenes.forEach((x, i) => x.characters.includes(c.name) && ((d.frames[i] = { status: "todo" }), (d.shots[i] = { status: "todo" })));
    } else if (a.what === "line") {
      const lines = d.lines.filter((l) => l.scene === sc);
      const l = lines[(a.index ?? 1) - 1];
      scene();
      if (!l) throw new Error(`Scene ${a.scene} has ${lines.length} line(s).`);
      if (a.text) l.text = a.text;
      Object.assign(l, { status: "todo", file: undefined, seconds: undefined });
    } else if (a.what === "frame") {
      if (a.prompt) scene().image_prompt = a.prompt;
      else scene();
      d.frames[sc] = { status: "todo" };
      d.shots[sc] = { status: "todo" };
    } else if (a.what === "shot") {
      if (a.motion) scene().motion_prompt = a.motion;
      else scene();
      d.shots[sc] = { status: "todo" };
    } else if (a.what === "sound") {
      if (a.prompt) scene().sound = a.prompt;
      else scene();
      d.sounds[sc] = { status: "todo" };
    } else if (a.what === "music") {
      if (a.prompt) s.music = a.prompt;
      d.music = undefined;
    }
    d.final = undefined;
    this.note(d, `marked ${a.what}${a.scene ? ` ${a.scene}` : a.character ? ` ${a.character}` : ""} to make again`);
    return this.summary(d);
  }

  // The price of everything still to make with the chosen providers - what the user approves before a run.
  quote(d: Drama, stages: readonly Stage[] = STAGES) {
    const s = d.script;
    const todo = (items: Item[]) => items.filter((i) => i.status !== "done").length;
    // Before the script exists, the episode is priced from its brief: about one shot per 7 seconds, three
    // characters, and some 14 characters of dialogue per second - so the first yes covers the whole run.
    const bp = blueprint(d.brief.type);
    const secs = d.brief.seconds ?? bp.default_seconds;
    const shotsGuess = planShots(bp, secs, d.brief.scenes);
    const scenes = s?.scenes ?? [];
    const shotCount = s ? todo(d.shots) : shotsGuess;
    const shotSeconds = s ? scenes.reduce((n, sc, i) => n + (d.shots[i]?.status === "done" ? 0 : sc.seconds), 0) : secs;
    const castCount = s ? Object.values(d.cast).filter((c) => c.status !== "done").length : 3;
    const frameCount = s ? todo(d.frames) : shotsGuess;
    const lineChars = s ? d.lines.filter((l) => l.status !== "done").reduce((n, l) => n + l.text.length, 0) : secs * 14;
    return estimate({
      writer: stages.includes("write") && !s ? d.providers.writer.id : undefined,
      image: d.providers.image,
      images: (stages.includes("cast") ? castCount : 0) + (stages.includes("frames") ? frameCount : 0),
      video: d.providers.video,
      shot_seconds: stages.includes("shots") ? shotSeconds : 0,
      shots: stages.includes("shots") ? shotCount : 0,
      voice: d.providers.voice,
      voice_chars: stages.includes("voices") ? lineChars : 0,
      sounds: stages.includes("sound") && d.providers.sound_effects ? (s ? todo(d.sounds) : shotsGuess) : 0,
      music: stages.includes("sound") && d.providers.music.id === "elevenlabs" && !d.music ? 1 : 0,
      max_credits: d.options.max_credits,
    });
  }

  summary(d: Drama) {
    const count = (items: Item[]) => ({ done: items.filter((i) => i.status === "done").length, failed: items.filter((i) => i.status === "failed").length, total: items.length });
    return {
      title: d.brief.title,
      slug: d.slug,
      folder: d.dir,
      updated: d.updated,
      type: d.brief.type ?? "custom",
      platform: d.brief.platform,
      aspect: d.options.aspect,
      seconds: d.brief.seconds,
      providers: d.providers,
      options: d.options,
      running: d.running ?? null,
      written: Boolean(d.script),
      progress: {
        cast: count(Object.values(d.cast)),
        voices: count(d.lines),
        frames: count(d.frames),
        shots: count(d.shots),
        sound: count(d.sounds),
        final: d.final?.status ?? "todo",
      },
      spent: { usd_estimate: Number(d.spent_usd.toFixed(2)), flow_credits: d.spent_credits },
      still_to_pay: this.quote(d),
      final: d.final?.status === "done" ? { film: d.final.file, captioned: d.final.captioned } : undefined,
      warnings: d.warnings ?? [],
      errors: [
        ...Object.entries(d.cast).filter(([, c]) => c.error).map(([n, c]) => `${n}: ${c.error}`),
        ...d.lines.flatMap((l, i) => (l.error ? [`line ${i + 1} (scene ${l.scene + 1}): ${l.error}`] : [])),
        ...d.frames.flatMap((f, i) => (f.error ? [`frame ${i + 1}: ${f.error}`] : [])),
        ...d.shots.flatMap((f, i) => (f.error ? [`shot ${i + 1}: ${f.error}`] : [])),
        ...d.sounds.flatMap((f, i) => (f.error ? [`sound ${i + 1}: ${f.error}`] : [])),
        ...(d.final?.error ? [`final: ${d.final.error}`] : []),
      ],
      log: d.log.slice(-12),
    };
  }

  detail(slug: string) {
    const d = this.load(slug);
    return { ...this.summary(d), brief: d.brief, script: d.script, cast: d.cast, lines: d.lines, frames: d.frames, shots: d.shots, sounds: d.sounds, music: d.music };
  }

  // Starts the stages in the background and returns at once; flow_drama_status (or the panel) follows along.
  start(slug: string, stages: readonly Stage[] = STAGES, confirm: { usd?: number; flow_credits?: boolean } = {}) {
    const d = this.load(slug);
    if (this.live.has(d.slug)) throw new Error("This drama is already being made.");
    const q = this.quote(d, stages);
    // Spending needs the user's yes: money up to an amount they approved, and Flow credits by an explicit OK.
    const usd = confirm.usd ?? 0;
    if (q.usd > 0.005 && usd + 0.005 < q.usd) {
      throw new Error(`This run would cost about $${q.usd.toFixed(2)} (${q.lines.join("; ")}). Ask the user, then run again with confirm_spend_usd of at least ${q.usd.toFixed(2)}`);
    }
    if (q.flow_credits > 0 && !confirm.flow_credits) {
      throw new Error(`This run would use up to ${q.flow_credits} Flow credits (${q.lines.join("; ")}). Ask the user, then run again with confirm_flow_credits: true.`);
    }
    d.approved_usd = d.spent_usd + Math.max(usd, q.usd);
    this.save(d);
    const job = this.pipeline(d.slug, stages).finally(() => this.live.delete(d.slug));
    this.live.set(d.slug, job);
    return { started: true, stages, quote: q, follow: "flow_drama_status shows progress; nothing else needs calling while it runs." };
  }

  busy = (slug: string) => this.live.has(slugOf(slug));

  private async pipeline(slug: string, stages: readonly Stage[]) {
    for (const stage of STAGES) {
      if (!stages.includes(stage)) continue;
      let d = this.load(slug);
      if (d.pause_requested) { d.pause_requested = false; d.running = undefined; this.note(d, "paused before " + stage); return; }
      d.running = { stage, since: new Date().toISOString() };
      this.note(d, `${stage}: started`);
      try {
        await this[stage](slug);
        const after = this.load(slug);
        this.note(after, `${stage}: finished`);
      } catch (err) {
        const after = this.load(slug);
        after.running = undefined;
        after.pause_requested = false;
        this.note(after, `${stage}: stopped - ${err instanceof Error ? err.message : String(err)}`);
        return;
      }
    }
    const d = this.load(slug);
    d.running = undefined;
    this.note(d, "all done");
  }

  // Runs one item, records success or the reason it failed, and keeps going with the rest.
  private async each<T extends Item | Line>(slug: string, pick: (d: Drama) => T[], label: (i: number) => string, make: (d: Drama, i: number) => Promise<Partial<T>>) {
    const total = pick(this.load(slug)).length;
    let failed = 0;
    for (let i = 0; i < total; i++) {
      let d = this.load(slug);
      if (d.pause_requested) throw new Error("paused by user");
      if (pick(d)[i].status === "done") continue;
      d.running = { ...d.running!, item: label(i) };
      Object.assign(pick(d)[i], { status: "running", error: undefined });
      this.save(d);
      try {
        const out = await make(d, i);
        d = this.load(slug);
        Object.assign(pick(d)[i], out, { status: "done", error: undefined });
        const cost = (out as Item).cost_usd ?? 0;
        d.spent_usd += cost;
        d.spent_credits += (out as Item).credits ?? 0;
        this.note(d, `${label(i)} done${cost ? ` (~$${cost.toFixed(2)})` : ""}`);
        if (d.spent_usd > d.approved_usd + 0.5) throw new Error(`Spending reached $${d.spent_usd.toFixed(2)}, past the $${d.approved_usd.toFixed(2)} you approved. Stopped to be safe.`);
        if (d.options.budget_credits !== undefined && d.spent_credits > d.options.budget_credits) throw new Error(`Flow credits spent (${d.spent_credits}) past the cap you set (${d.options.budget_credits}). Stopped to be safe.`);
      } catch (err) {
        failed++;
        d = this.load(slug);
        Object.assign(pick(d)[i], { status: "failed", error: err instanceof Error ? err.message : String(err) });
        this.note(d, `${label(i)} failed: ${pick(d)[i].error}`);
        if (/past the .* you approved|No .* key yet|didn't accept|isn't running/i.test(String(pick(d)[i].error))) throw err;
      }
    }
    if (failed) throw new Error(`${failed} item(s) failed - see errors; fix or redo them and run again.`);
  }

  private async write(slug: string) {
    const d = this.load(slug);
    if (d.script) return;
    if (d.providers.writer.id === "chat") throw new Error("Waiting for the script: ask Claude in chat to write it (flow_drama_script).");
    const s = await writeScript(d.providers.writer.id, d.providers.writer.model, d.brief);
    const after = this.load(slug);
    this.adopt(after, s);
    after.spent_usd += this.quote({ ...after, script: undefined }, ["write"]).usd;
    this.note(after, `script written: ${s.scenes.length} shots, ${s.characters.length} characters`);
  }

  private names = (d: Drama) => d.script!.characters.map((c) => c.name);

  private async cast(slug: string) {
    const names = this.names(this.load(slug));
    const pick = (d: Drama) => names.map((n) => d.cast[n]);
    await this.each(slug, pick, (i) => `portrait of ${names[i]}`, async (d, i) => {
      const c = d.script!.characters[i];
      const look = `${d.script!.visual_style.trim().replace(/[.\s]*$/, "")}. Character reference sheet portrait of ${c.name}, ${c.role}: ${c.look}. Full figure and clear face, neutral plain background, even light, no text.`;
      const dir = join(d.dir, "cast");
      mkdirSync(dir, { recursive: true });
      if (d.providers.image.id === "flow") {
        const made = await this.flow.character(`${c.name} - ${d.slug}`.slice(0, 60), look);
        const file = made.portrait ? copyInto(made.portrait, dir, slugOf(c.name)) : undefined;
        return { file, asset: made.asset };
      }
      const out = await makeImage(d.providers.image.id, d.providers.image.model, look, [], join(dir, slugOf(c.name)));
      return { file: out.file, cost_usd: out.cost_usd };
    });
  }

  private async voices(slug: string) {
    let d = this.load(slug);
    const s = d.script!;
    // Each character keeps one voice for the whole episode; any not chosen by the user get a distinct match.
    const missing = s.characters.filter((c) => !d.cast[c.name]?.voice || d.cast[c.name].voice!.provider !== d.providers.voice.id);
    const narrated = d.lines.some((l) => l.character === "Narrator");
    if (missing.length || narrated) {
      const chosen = await pickVoices(d.providers.voice.id, [...missing, ...(narrated && !d.cast.Narrator?.voice ? [{ name: "Narrator", voice: "calm, warm, middle-aged storyteller" }] : [])], d.brief.title, s.language);
      d = this.load(slug);
      for (const [name, v] of Object.entries(chosen)) d.cast[name] = { ...(d.cast[name] ?? { status: "done" }), voice: v };
      this.save(d);
    }
    await this.each(slug, (x) => x.lines, (i) => `line ${i + 1}`, async (dd, i) => {
      const l = dd.lines[i];
      const v = dd.cast[l.character]?.voice;
      if (!v) throw new Error(`"${l.character}" isn't in the cast, so has no voice.`);
      const dir = join(dd.dir, "voices");
      mkdirSync(dir, { recursive: true });
      const out = await speakLine(dd.providers.voice.id, dd.providers.voice.model, v, l.text, l.emotion, s.language, join(dir, `s${String(l.scene + 1).padStart(2, "0")}-${String(i + 1).padStart(3, "0")}`));
      return { file: out.file, seconds: out.seconds ?? (await seconds(out.file)), cost_usd: out.cost_usd };
    });
  }

  private async frames(slug: string) {
    await this.each(slug, (d) => d.frames, (i) => `frame ${i + 1}`, async (d, i) => {
      const s = d.script!;
      const sc = s.scenes[i];
      const people = sc.characters.map((n) => s.characters.find((c) => c.name === n)).filter((c): c is Script["characters"][number] => Boolean(c));
      const who = people.map((c) => `${c.name} is exactly: ${c.look}`).join(" ");
      const aspect = d.options.aspect ?? "9:16";
      const framing = aspect === "9:16" ? "Vertical 9:16" : aspect === "16:9" ? "Widescreen 16:9" : aspect === "1:1" ? "Square 1:1" : "Portrait 4:5";
      const prompt = `${s.visual_style}. ${framing} film still. ${sc.image_prompt.trim().replace(/[.\s]*$/, ".")} Location: ${sc.location}. ${who} Keep every character identical to their reference image. No text, captions or logos.`;
      const dir = join(d.dir, "frames");
      mkdirSync(dir, { recursive: true });
      const stem = `frame-${String(i + 1).padStart(2, "0")}`;
      if (d.providers.image.id === "flow") {
        const refs = people.map((c) => d.cast[c.name]?.asset ?? d.cast[c.name]?.file).filter((r): r is string => Boolean(r)).slice(0, 3);
        return { file: await this.flow.image(prompt, refs, dir, stem) };
      }
      const refs = people.map((c) => d.cast[c.name]?.file).filter((r): r is string => Boolean(r && existsSync(r)));
      const out = await makeImage(d.providers.image.id, d.providers.image.model, prompt, refs, join(dir, stem));
      return { file: out.file, cost_usd: out.cost_usd };
    });
  }

  // Shots come after voices so each one can be made long enough for the lines spoken in it.
  private async shots(slug: string) {
    await this.each(slug, (d) => d.shots, (i) => `shot ${i + 1}`, async (d, i) => {
      const s = d.script!;
      const sc = s.scenes[i];
      const frame = d.frames[i]?.file;
      if (!frame || !existsSync(frame)) throw new Error(`Frame ${i + 1} isn't made yet.`);
      const talk = timeline(d).scenes[i]?.speech ?? 0;
      const want = Math.max(sc.seconds, Math.ceil(talk + 0.6));
      const speaking = sc.dialogue.length ? ` ${sc.dialogue.map((l) => `${l.character} speaks (${l.emotion})`).join(", then ")}; mouths move naturally.` : "";
      const aspect = d.options.aspect ?? "9:16";
      const framing = aspect === "9:16" ? "Vertical 9:16" : aspect === "16:9" ? "Widescreen 16:9" : aspect === "1:1" ? "Square 1:1" : "Portrait 4:5";
      const prompt = `${s.visual_style}. ${sc.motion_prompt}.${speaking} Keep the characters, outfits and setting exactly as in the first frame. ${framing}.`;
      const dir = join(d.dir, "shots");
      mkdirSync(dir, { recursive: true });
      const stem = `shot-${String(i + 1).padStart(2, "0")}`;
      if (d.providers.video.id === "flow") {
        const fit = [4, 6, 8, 10].find((x) => x >= want) ?? 10;
        const made = await this.flow.video(prompt, frame, fit, d.providers.video.model, d.options.max_credits, dir, stem);
        return { file: made.file, credits: made.credits };
      }
      const out = await makeVideo(d.providers.video.id, d.providers.video.model, prompt, frame, want, join(dir, stem));
      return { file: out.file, cost_usd: out.cost_usd };
    });
  }

  private async sound(slug: string) {
    const d0 = this.load(slug);
    if (d0.providers.sound_effects) {
      await this.each(slug, (d) => d.sounds, (i) => `sound ${i + 1}`, async (d, i) => {
        const sc = d.script!.scenes[i];
        if (!sc.sound) return { file: undefined };
        const dir = join(d.dir, "sound");
        mkdirSync(dir, { recursive: true });
        const out = await makeSound(sc.sound, Math.min(10, sc.seconds), join(dir, `sound-${String(i + 1).padStart(2, "0")}`));
        return { file: out.file, cost_usd: out.cost_usd };
      });
    }
    const d = this.load(slug);
    if (d.providers.music.id === "elevenlabs" && d.music?.status !== "done") {
      const total = timeline(d).total;
      const out = await makeMusic(d.script!.music, Math.ceil(total), join(d.dir, "music"));
      const after = this.load(slug);
      after.music = { status: "done", file: out.file, cost_usd: out.cost_usd };
      after.spent_usd += out.cost_usd ?? 0;
      this.note(after, "music made");
    } else if (d.providers.music.id === "file") {
      if (!d.providers.music.file || !existsSync(d.providers.music.file)) throw new Error("The music file isn't there any more. Pick it again.");
    }
  }

  private async qa(slug: string) {
    const d = this.load(slug);
    d.warnings = checkDrama(d);
    if (d.warnings.length) this.note(d, `QA: ${d.warnings.length} warning(s) — see flow_drama_status`);
    this.save(d);
  }

  private async cut(slug: string) {
    const d = this.load(slug);
    await measureShots(d);
    const missing = d.shots.findIndex((s) => s.status !== "done" || !s.file || !existsSync(s.file));
    if (missing >= 0) throw new Error(`Shot ${missing + 1} isn't made yet.`);
    const t = timeline(d);
    const lines = d.lines
      .map((l, i) => ({ l, at: t.lineAt[i] }))
      .filter(({ l }) => l.status === "done" && l.file && existsSync(l.file))
      .map(({ l, at }) => ({ file: l.file!, at, max_seconds: (l.seconds ?? 0) * 1.25 || undefined }));
    // Sound effects ride on the same timed track as the lines, quietly, at the start of their shot.
    const fx = d.sounds.map((s, i) => ({ s, at: t.scenes[i].start + 0.05 })).filter(({ s }) => s.status === "done" && s.file && existsSync(s.file)).map(({ s, at }) => ({ file: s.file!, at }));
    const all = [...lines, ...fx].sort((a, b) => a.at - b.at).slice(0, 60);
    const voice = all.length ? await voiceTrack(all, join(d.dir, "dialogue.wav")) : undefined;
    const music = d.providers.music.id === "elevenlabs" ? d.music?.file : d.providers.music.id === "file" ? d.providers.music.file : undefined;
    const film = await assemble({
      dir: d.dir,
      clips: t.scenes.map((x) => x.clip),
      voiceover: voice?.file,
      music,
      music_volume: d.options.music_volume,
      clip_volume: d.options.clip_volume,
      output_name: `${d.slug}-episode`,
      hold_last_frame: true,
    });
    let captioned: string | undefined;
    if (d.options.captions && lines.length) {
      const words = d.lines.filter((l) => l.status === "done").map((l) => l.text).join("\n");
      const c = await burnCaptions(film.output, { style: d.options.caption_style, position: "bottom", size: "medium", language: d.script!.language, text: words, names: this.names(d) }, captionedName(d.dir, film.output));
      captioned = c.output;
    }
    const after = this.load(slug);
    after.final = { status: "done", file: film.output, captioned };
    this.note(after, `episode cut: ${film.duration.toFixed(1)} s${captioned ? ", with captions" : ""}`);
  }
}

// Where every shot starts in the film and where each line lands inside its shot.
export function timeline(d: Drama) {
  const s = d.script!;
  let start = 0;
  const lineAt: number[] = [];
  const scenes = s.scenes.map((sc, i) => {
    const mine = d.lines.map((l, j) => ({ l, j })).filter(({ l }) => l.scene === i);
    let at = 0.3;
    for (const { l, j } of mine) {
      lineAt[j] = start + at;
      at += (l.seconds ?? Math.ceil(l.text.split(/\s+/).length / 2.5)) + 0.2;
    }
    const speech = at - 0.2;
    const clip = d.shots[i]?.file ?? "";
    const length = clipSeconds.get(clip) ?? sc.seconds;
    const out = { start, clip, length, speech };
    start += length;
    return out;
  });
  return { scenes, lineAt, total: start };
}

const clipSeconds = new Map<string, number>();
async function seconds(file: string): Promise<number> {
  const { stdout } = await run(FFPROBE, ["-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", file]);
  const n = Number(stdout.trim()) || 0;
  clipSeconds.set(file, n);
  return n;
}
export async function measureShots(d: Drama) {
  for (const s of d.shots) if (s.file && existsSync(s.file) && !clipSeconds.has(s.file)) await seconds(s.file);
}

function copyInto(src: string, dir: string, stem: string) {
  const ext = src.match(/\.\w+$/)?.[0] ?? ".png";
  const out = join(dir, stem + ext);
  copyFileSync(src, out);
  return out;
}

export { IMAGE_PROVIDERS, VIDEO_PROVIDERS, VOICE_PROVIDERS };
