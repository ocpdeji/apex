// A production blueprint tells the writer what kind of video to write and the pipeline how to pace it. Each type is its
// own set of rules: the writer's instructions, how long an average shot runs, which caption style suits it, and the
// default voice temperament. The chosen blueprint reaches every stage of the pipeline, so a documentary comes out as
// narration + evidence-driven shots and a drama as dialogue-driven shots, not both the same with a different label.

export type BlueprintId =
  | "micro_drama" | "documentary" | "bible" | "ugc" | "youtube_long" | "youtube_short"
  | "tiktok" | "reels" | "product_ad" | "explainer" | "animated" | "trailer"
  | "podcast" | "music_montage" | "custom";

export interface Blueprint {
  id: BlueprintId;
  label: string;
  summary: string;
  default_aspect: "9:16" | "16:9" | "1:1" | "4:5";
  default_seconds: number;
  seconds_per_shot: number;
  min_shots: number;
  max_shots: number;
  default_caption_style: "bold" | "highlight" | "reveal" | "clean" | "boxed";
  default_voice_mood: string;
  needs_narrator: boolean;
  // Added to the writer's system prompt so the script matches the type, not just its name.
  writer_rules: string;
  // Appended to the user prompt so the writer plans the right structure, pacing, and ending.
  structure: string;
}

export const BLUEPRINTS: Record<BlueprintId, Blueprint> = {
  micro_drama: {
    id: "micro_drama", label: "Micro-drama", summary: "Vertical dialogue-driven drama with a hook and a cliffhanger.",
    default_aspect: "9:16", default_seconds: 60, seconds_per_shot: 6, min_shots: 6, max_shots: 20,
    default_caption_style: "bold", default_voice_mood: "emotional, performed, not narrated",
    needs_narrator: false,
    writer_rules: "You are the head writer for a hit vertical micro-drama studio. You write tight, emotional, highly visual episodes.",
    structure: "Micro-drama rules: open on the hook in the first shot; a reversal or reveal every few shots; end on a cliffhanger. Lines short and punchy, dialogue-driven, no narrator unless the drama needs one.",
  },
  documentary: {
    id: "documentary", label: "Documentary", summary: "Narration + evidence-driven shots, chronological or thesis-driven.",
    default_aspect: "16:9", default_seconds: 180, seconds_per_shot: 8, min_shots: 10, max_shots: 60,
    default_caption_style: "clean", default_voice_mood: "measured, clear, documentary narrator",
    needs_narrator: true,
    writer_rules: "You are a documentary director. You write evidence-aware, clear, chronological narration with illustrative visuals and a thesis.",
    structure: "Documentary rules: open with a thesis and a cold-open hook; move chronologically or thesis-by-point; narration carries the story and dialogue is sparse or in short interview clips; distinguish verified facts from interpretation; end with a resolution of the thesis. Keep narration intelligible — not more than about 2.4 words a second.",
  },
  bible: {
    id: "bible", label: "Bible story", summary: "Reverent, historically-informed retelling of a Bible story.",
    default_aspect: "16:9", default_seconds: 240, seconds_per_shot: 9, min_shots: 10, max_shots: 50,
    default_caption_style: "clean", default_voice_mood: "warm, reverent, storytelling narrator",
    needs_narrator: true,
    writer_rules: "You are a Bible-story screenwriter. You retell the passage respectfully, with historically-informed settings and costumes, and distinguish direct scripture from dramatized dialogue.",
    structure: "Bible-story rules: open by naming the passage and setting; follow the passage's own order of events; keep dialogue consistent with the text where it exists and clearly dramatized where it does not; close with the passage's resolution and a one-line reflection. If the user names a passage, honour it; do not invent miracles or events the passage does not include.",
  },
  ugc: {
    id: "ugc", label: "UGC / creator-style", summary: "Natural, conversational creator talking to camera, with b-roll.",
    default_aspect: "9:16", default_seconds: 30, seconds_per_shot: 4, min_shots: 5, max_shots: 15,
    default_caption_style: "bold", default_voice_mood: "casual, friendly, speaking to a friend",
    needs_narrator: false,
    writer_rules: "You are a creator-style scriptwriter. You write conversational, relatable scripts for a single on-camera presenter, with short b-roll shots to break up the talking head.",
    structure: "UGC rules: hook in the first 3 seconds (a surprising claim, question, or demonstration); alternate talking-head shots with b-roll of the subject or product; keep the delivery natural, not read; end with a clear call to action.",
  },
  youtube_long: {
    id: "youtube_long", label: "YouTube long-form", summary: "Landscape longer-form video with narration and chapters.",
    default_aspect: "16:9", default_seconds: 600, seconds_per_shot: 10, min_shots: 15, max_shots: 90,
    default_caption_style: "clean", default_voice_mood: "friendly, well-paced, YouTube narrator",
    needs_narrator: true,
    writer_rules: "You are a YouTube writer. You write watchable long-form landscape videos with a strong intro, clear chapters, and a payoff.",
    structure: "YouTube long-form rules: open with a 10-second hook and a one-line promise; group shots into 3-5 chapters that each advance the premise; narration carries the story, with occasional on-screen quotes or dialogue; end with a payoff and a subscribe-style call to action.",
  },
  youtube_short: {
    id: "youtube_short", label: "YouTube Short", summary: "Vertical short with an instant hook and a quick payoff.",
    default_aspect: "9:16", default_seconds: 45, seconds_per_shot: 4, min_shots: 6, max_shots: 15,
    default_caption_style: "bold", default_voice_mood: "energetic, fast, hook-forward",
    needs_narrator: false,
    writer_rules: "You are a YouTube Shorts writer. You hook in the first 2 seconds, deliver one clear idea, and end on a payoff.",
    structure: "Shorts rules: open on the single strongest image; one idea, no digressions; every shot earns its place; end on a payoff, loop point, or a one-line call to action.",
  },
  tiktok: {
    id: "tiktok", label: "TikTok", summary: "Vertical, high-energy, trend-aware short.",
    default_aspect: "9:16", default_seconds: 30, seconds_per_shot: 3, min_shots: 6, max_shots: 15,
    default_caption_style: "bold", default_voice_mood: "fast, playful, conversational",
    needs_narrator: false,
    writer_rules: "You are a TikTok writer. You write quick, visual, trend-aware shorts with an instant hook and strong on-screen captions.",
    structure: "TikTok rules: hook in the first 1-2 seconds; one idea at speed; captions are a core part of the storytelling; end on a satisfying beat or a call to comment.",
  },
  reels: {
    id: "reels", label: "Instagram Reels", summary: "Vertical, polished, hook-forward.",
    default_aspect: "9:16", default_seconds: 30, seconds_per_shot: 4, min_shots: 5, max_shots: 15,
    default_caption_style: "highlight", default_voice_mood: "polished, warm, confident",
    needs_narrator: false,
    writer_rules: "You are an Instagram Reels writer. You write polished, hook-forward verticals with a clean, aspirational tone.",
    structure: "Reels rules: open with a visual hook and a one-line promise; move through 4-8 clean beats; end on an aesthetic payoff and a save-worthy takeaway.",
  },
  product_ad: {
    id: "product_ad", label: "Product advertisement", summary: "Short ad with a hook, a product beat, and a call to action.",
    default_aspect: "9:16", default_seconds: 30, seconds_per_shot: 4, min_shots: 5, max_shots: 12,
    default_caption_style: "bold", default_voice_mood: "warm, confident, benefit-first",
    needs_narrator: true,
    writer_rules: "You are a direct-response ad writer. You lead with the problem, show the product solving it, and end with a clear call to action.",
    structure: "Ad rules: open with a 2-second problem hook; show the product in use within the first 10 seconds; benefits over features; close with one clear call to action. Only make a claim the user's premise supports.",
  },
  explainer: {
    id: "explainer", label: "Explainer / educational", summary: "Narrated explanation with illustrative visuals.",
    default_aspect: "16:9", default_seconds: 90, seconds_per_shot: 6, min_shots: 8, max_shots: 25,
    default_caption_style: "clean", default_voice_mood: "clear, friendly teacher",
    needs_narrator: true,
    writer_rules: "You are an explainer writer. You explain one idea clearly, with narration and illustrative visuals, in the shortest honest form.",
    structure: "Explainer rules: open with the question the video answers; build the answer in 3-5 steps; one visual per step; end with a one-line summary.",
  },
  animated: {
    id: "animated", label: "Animated story", summary: "Animated short, consistent style throughout.",
    default_aspect: "9:16", default_seconds: 60, seconds_per_shot: 6, min_shots: 6, max_shots: 25,
    default_caption_style: "bold", default_voice_mood: "warm, storybook narrator",
    needs_narrator: true,
    writer_rules: "You are an animated-story writer. You write a short that reads as one coherent animated piece, with a strong beginning, middle, and end.",
    structure: "Animated-story rules: name the style once (3D animation, flat 2D, storybook, anime) and keep it for every shot; characters stay on-model; a single clear arc with a satisfying ending.",
  },
  trailer: {
    id: "trailer", label: "Cinematic trailer", summary: "Short, high-impact teaser with music beats.",
    default_aspect: "16:9", default_seconds: 60, seconds_per_shot: 3, min_shots: 10, max_shots: 25,
    default_caption_style: "bold", default_voice_mood: "epic, measured, movie-trailer narrator",
    needs_narrator: true,
    writer_rules: "You are a trailer editor and copywriter. You write a trailer: imagery first, a short title card, three questions it makes the audience ask, and a release line.",
    structure: "Trailer rules: imagery over dialogue; short, resonant narration lines spaced through the trailer; music beats drive the cuts; end with a title card line.",
  },
  podcast: {
    id: "podcast", label: "Podcast video", summary: "Talking heads with light b-roll, speech-driven.",
    default_aspect: "16:9", default_seconds: 300, seconds_per_shot: 10, min_shots: 10, max_shots: 60,
    default_caption_style: "clean", default_voice_mood: "conversational, warm, two-person dialogue",
    needs_narrator: false,
    writer_rules: "You are a podcast-video director. You write short, natural dialogue between hosts, with occasional illustrative b-roll.",
    structure: "Podcast rules: dialogue over narration; one speaker per shot in close talking-head, with b-roll every few shots to illustrate; keep energy conversational, not performative; end on a wrap-up line and an outro.",
  },
  music_montage: {
    id: "music_montage", label: "Music-driven montage", summary: "Visual montage over a music track, no narration.",
    default_aspect: "9:16", default_seconds: 45, seconds_per_shot: 3, min_shots: 10, max_shots: 25,
    default_caption_style: "clean", default_voice_mood: "silent",
    needs_narrator: false,
    writer_rules: "You are a music-video editor. You plan a montage over a music track, with no narration and almost no dialogue — the images and music carry the story.",
    structure: "Montage rules: imagery-first; dialogue only as a short line to open or close; cuts land on strong music beats; end on a resonant image, not a title card.",
  },
  custom: {
    id: "custom", label: "Custom", summary: "No preset; follow the user's directions.",
    default_aspect: "9:16", default_seconds: 60, seconds_per_shot: 6, min_shots: 4, max_shots: 40,
    default_caption_style: "bold", default_voice_mood: "match the idea",
    needs_narrator: false,
    writer_rules: "You are a flexible AI film director. You read the user's idea carefully and pick the structure and tone that best serve it.",
    structure: "Custom rules: follow the user's own directions in the idea. If they don't specify a structure, choose the one that best fits the premise and say so in the logline.",
  },
};

export const blueprint = (id?: string): Blueprint => BLUEPRINTS[(id as BlueprintId) in BLUEPRINTS ? (id as BlueprintId) : "custom"];

// Scene count from a blueprint and a target length, bounded to what the type allows.
export const planShots = (bp: Blueprint, seconds: number, want?: number) => {
  const guess = want ?? Math.max(bp.min_shots, Math.min(bp.max_shots, Math.round(seconds / bp.seconds_per_shot)));
  return Math.max(bp.min_shots, Math.min(bp.max_shots, guess));
};
