import { existsSync, statSync } from "node:fs";
import type { Drama } from "./drama.js";
import { blueprint } from "./blueprints.js";

// Quality-control warnings for a drama. Deterministic file-and-metadata checks only - never a claim that an image "looks
// wrong". Returned warnings surface in flow_drama_status so the user can decide whether to redo an item before the cut.
export function checkDrama(d: Drama): string[] {
  const warnings: string[] = [];
  const s = d.script;
  if (!s) return warnings;
  const minSize = (path: string, kb: number) => existsSync(path) && statSync(path).size < kb * 1024;
  for (const [name, c] of Object.entries(d.cast)) {
    if (c.file && minSize(c.file, 5)) warnings.push(`${name}'s portrait is smaller than 5 KB — likely corrupted.`);
  }
  s.scenes.forEach((sc, i) => {
    const f = d.frames[i], sh = d.shots[i];
    if (f?.status === "done" && (!f.file || !existsSync(f.file))) warnings.push(`Frame ${i + 1} is marked done but its file is missing.`);
    if (sh?.status === "done" && (!sh.file || !existsSync(sh.file))) warnings.push(`Shot ${i + 1} is marked done but its file is missing.`);
    if (f?.file && minSize(f.file, 5)) warnings.push(`Frame ${i + 1} is smaller than 5 KB — likely corrupted.`);
    if (sh?.file && minSize(sh.file, 60)) warnings.push(`Shot ${i + 1} is smaller than 60 KB — likely a failed render.`);
    const words = [...sc.dialogue.map((x) => x.line), sc.narration ?? ""].join(" ").split(/\s+/).filter(Boolean).length;
    const need = Math.ceil(words / 2.5);
    if (need > sc.seconds + 1.5) warnings.push(`Shot ${i + 1} has ${words} spoken words in ${sc.seconds}s — needs about ${need}s to fit comfortably.`);
    // Unknown characters: a shot that names a character not in the cast won't get a reference image.
    for (const c of sc.characters) {
      if (!s.characters.some((x) => x.name === c)) warnings.push(`Shot ${i + 1} names "${c}", who is not in the cast.`);
    }
  });
  const sawLines = d.lines.filter((l) => l.status === "done").length;
  const expLines = d.lines.length;
  if (expLines > 0 && sawLines < expLines) warnings.push(`${expLines - sawLines} line(s) are not recorded yet; the final cut will skip them.`);
  // Blueprint hints
  const bp = blueprint(d.brief.type);
  const total = s.scenes.reduce((n, sc) => n + sc.seconds, 0);
  const target = d.brief.seconds ?? bp.default_seconds;
  if (Math.abs(total - target) > Math.max(5, target * 0.2)) warnings.push(`Planned runtime (${total}s) is far from the target (${target}s). The pipeline will cut what shots it has.`);
  return warnings;
}
