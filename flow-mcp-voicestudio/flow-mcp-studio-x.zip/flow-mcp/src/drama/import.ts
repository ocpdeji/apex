import { copyFileSync, existsSync, mkdirSync } from "node:fs";
import { basename, extname, join } from "node:path";
import { transcribe } from "../captions.js";
import { BLUEPRINTS, blueprint } from "./blueprints.js";
import type { Script } from "./script.js";

// A video-to-video import: the pipeline reads an existing video, transcribes it, and builds a drama around it. The
// source file is never changed - a copy of it is saved next to the drama. From here the user can edit the script and
// re-render.
export interface Imported {
  original: string;
  copy: string;
  seconds: number;
  words: number;
  language: string;
  script: Script;
}

export async function importVideo(a: { video: string; title: string; type?: string; aspect?: "9:16" | "16:9" | "1:1" | "4:5"; language?: string; dir: string }): Promise<Imported> {
  if (!existsSync(a.video)) throw new Error(`There's no file at ${a.video}.`);
  if (!/\.(mp4|mov|webm|m4v|mkv|mp3|m4a|wav)$/i.test(a.video)) throw new Error("Only video or audio files can be imported.");
  mkdirSync(a.dir, { recursive: true });
  const copy = join(a.dir, "source" + extname(a.video).toLowerCase());
  copyFileSync(a.video, copy);
  const t = await transcribe(copy, a.language ?? "auto");
  // Break the words into shot-length groups by pauses in speech, so the drama has roughly the same beats as the video.
  const bp = blueprint(a.type);
  const seconds = t.words.length ? Math.ceil(t.words[t.words.length - 1].end) : 60;
  const shots: { start: number; end: number; text: string }[] = [];
  let cursor = 0;
  while (cursor < t.words.length) {
    const start = t.words[cursor].start;
    let end = start + bp.seconds_per_shot;
    let j = cursor;
    // Expand to the next word, extending to a sentence boundary if one lands within +50% of a shot's length.
    while (j < t.words.length && t.words[j].start < end) j++;
    while (j < t.words.length && t.words[j].start < start + bp.seconds_per_shot * 1.5 && !/[.!?]$/.test(t.words[j - 1]?.text ?? "")) j++;
    end = t.words[Math.min(j, t.words.length - 1)].end;
    shots.push({ start, end, text: t.words.slice(cursor, j).map((w) => w.text).join(" ").trim() });
    cursor = j;
  }
  // Build a Script shaped like a dramatic retelling: the imported words land as narration on each shot.
  const script: Script = {
    title: a.title,
    logline: `Edited retelling of "${basename(a.video)}" (${seconds.toFixed(1)}s, ${t.words.length} words).`,
    genre: bp.label,
    language: t.language ?? a.language ?? "en",
    visual_style: "match the look of the source video, consistent through every shot",
    hook: shots[0]?.text?.slice(0, 120) ?? "",
    cliffhanger: shots[shots.length - 1]?.text?.slice(0, 120) ?? "",
    characters: [{ name: "Narrator", role: "narrator", look: "not shown on screen", personality: "steady, warm", voice: "match the source narrator's voice" }],
    scenes: shots.map((sh, i) => ({
      location: `Scene ${i + 1}`,
      characters: [],
      image_prompt: `A still from the source video at ${sh.start.toFixed(1)}s. Match the lighting, framing and colour palette.`,
      motion_prompt: `Continuous take from ${sh.start.toFixed(1)}s to ${sh.end.toFixed(1)}s.`,
      seconds: Math.max(4, Math.min(10, Math.round(sh.end - sh.start) || bp.seconds_per_shot)),
      dialogue: [],
      narration: sh.text,
      sound: "",
    })),
    music: "optional underscore that follows the mood of the source video",
  };
  return { original: a.video, copy, seconds, words: t.words.length, language: script.language, script };
}

// A small catalogue the panel and MCP read so they both know which import types are available.
export const IMPORT_TYPES = Object.keys(BLUEPRINTS);
