#!/usr/bin/env node
// One-time setup: opens the dedicated Chrome profile on Flow so the user can sign in by hand.
import { activeAccount, activeProfileDir } from "./accounts.js";
import { getFlowPage } from "./chrome.js";

const name = activeAccount();
const page = await getFlowPage();
await page.bringToFront();
console.log(`Chrome is open on ${page.url()}`);
console.log(`Account: ${name}`);
console.log(`Profile: ${activeProfileDir()}`);
console.log("Sign in to Google in that window, then open or create a Flow project. The session is kept for next time.");
console.log("To add another account later, call flow_account_create then flow_account_switch and run `npm run login` again.");
process.exit(0);
